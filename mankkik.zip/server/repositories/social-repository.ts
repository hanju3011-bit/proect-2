import { and, asc, desc, eq, inArray, like, ne, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/mysql-core";
import { friendships, interactions, records, users, goals } from "../../drizzle/schema";
import { getDb } from "../db";
import type { FriendshipStatus } from "../domain/friendship";

const commentUsers = alias(users, "commentUsers");

export class SocialRepository {
  private async database() {
    const db = await getDb();
    if (!db) throw new Error("데이터베이스에 연결할 수 없습니다.");
    return db;
  }

  async searchUsers(userId: number, query: string) {
    const db = await this.database();
    const term = query.trim().replace(/[%_]/g, "");
    if (!term) return [];
    const filters = [like(users.nickname, `%${term}%`), like(users.publicId, `%${term}%`)];
    if (/^\d+$/.test(term)) filters.push(eq(users.id, Number(term)) as never);
    const rows = await db.select({ id: users.id, publicId: users.publicId, nickname: users.nickname, profileImg: users.profileImg })
      .from(users).where(and(ne(users.id, userId), or(...filters))).limit(12);
    return rows.map(row => ({ ...row, publicId: row.publicId ?? String(row.id), nickname: row.nickname ?? "만끽 사용자" }));
  }

  async sendFriendRequest(requesterId: number, receiverId: number) {
    const db = await this.database();
    const [target] = await db.select({ id: users.id }).from(users).where(eq(users.id, receiverId)).limit(1);
    if (!target) throw new Error("친구를 찾을 수 없습니다.");
    const [existing] = await db.select().from(friendships).where(or(
      and(eq(friendships.requesterId, requesterId), eq(friendships.receiverId, receiverId)),
      and(eq(friendships.requesterId, receiverId), eq(friendships.receiverId, requesterId)),
    )).limit(1);
    if (existing?.status === "accepted") throw new Error("이미 친구로 연결되어 있습니다.");
    if (existing?.status === "pending") {
      throw new Error(existing.receiverId === requesterId ? "상대가 보낸 친구 신청을 확인해 주세요." : "이미 친구 신청을 보냈습니다.");
    }
    if (existing) {
      await db.update(friendships).set({ requesterId, receiverId, status: "pending", updatedAt: new Date() }).where(eq(friendships.id, existing.id));
      return;
    }
    await db.insert(friendships).values({ requesterId, receiverId, status: "pending" });
  }

  async respondToRequest(receiverId: number, requesterId: number, status: "accepted" | "rejected") {
    const db = await this.database();
    const [request] = await db.select().from(friendships).where(and(
      eq(friendships.requesterId, requesterId), eq(friendships.receiverId, receiverId), eq(friendships.status, "pending"),
    )).limit(1);
    if (!request) throw new Error("처리할 친구 신청을 찾을 수 없습니다.");
    await db.update(friendships).set({ status, updatedAt: new Date() }).where(eq(friendships.id, request.id));
  }

  async listFriendRequests(userId: number) {
    const db = await this.database();
    return db.select({
      id: friendships.id,
      requesterId: users.id,
      publicId: users.publicId,
      nickname: users.nickname,
      profileImg: users.profileImg,
      createdAt: friendships.createdAt,
    }).from(friendships).innerJoin(users, eq(users.id, friendships.requesterId))
      .where(and(eq(friendships.receiverId, userId), eq(friendships.status, "pending")))
      .orderBy(desc(friendships.createdAt));
  }

  async friendIds(userId: number): Promise<number[]> {
    const db = await this.database();
    const relations = await db.select({ requesterId: friendships.requesterId, receiverId: friendships.receiverId })
      .from(friendships).where(and(or(eq(friendships.requesterId, userId), eq(friendships.receiverId, userId)), eq(friendships.status, "accepted")));
    return relations.map(relation => relation.requesterId === userId ? relation.receiverId : relation.requesterId);
  }

  async listFriends(userId: number) {
    const db = await this.database();
    const ids = await this.friendIds(userId);
    if (ids.length === 0) return [];
    const rows = await db.select({ id: users.id, publicId: users.publicId, nickname: users.nickname, profileImg: users.profileImg })
      .from(users).where(inArray(users.id, ids));
    return rows.map(row => ({ ...row, publicId: row.publicId ?? String(row.id), nickname: row.nickname ?? "만끽 사용자" }));
  }

  async listFeed(userId: number, limit = 30) {
    const db = await this.database();
    const friendIds = await this.friendIds(userId);
    if (friendIds.length === 0) return [];
    const rows = await db.select({
      id: records.id,
      userId: records.userId,
      amount: records.amount,
      category: records.category,
      memo: records.memo,
      imageUrl: records.imageUrl,
      spentAt: records.spentAt,
      nickname: users.nickname,
      publicId: users.publicId,
      profileImg: users.profileImg,
      goalTitle: goals.title,
    }).from(records)
      .innerJoin(users, eq(users.id, records.userId))
      .leftJoin(goals, eq(goals.id, records.goalId))
      .where(inArray(records.userId, friendIds))
      .orderBy(desc(records.spentAt))
      .limit(Math.min(Math.max(limit, 1), 50));
    if (rows.length === 0) return [];

    const recordIds = rows.map(row => row.id);
    const allInteractions = await db.select({
      id: interactions.id,
      recordId: interactions.recordId,
      userId: interactions.userId,
      type: interactions.type,
      comment: interactions.comment,
      createdAt: interactions.createdAt,
      nickname: commentUsers.nickname,
      publicId: commentUsers.publicId,
    }).from(interactions).innerJoin(commentUsers, eq(commentUsers.id, interactions.userId))
      .where(inArray(interactions.recordId, recordIds)).orderBy(asc(interactions.createdAt));

    return rows.map(row => {
      const itemInteractions = allInteractions.filter(item => item.recordId === row.id);
      const likes = itemInteractions.filter(item => item.type === "like");
      const comments = itemInteractions.filter(item => item.type === "comment").map(item => ({
        id: item.id,
        userId: item.userId,
        nickname: item.nickname ?? "만끽 사용자",
        publicId: item.publicId ?? String(item.userId),
        comment: item.comment ?? "",
        createdAt: item.createdAt,
      }));
      return {
        ...row,
        nickname: row.nickname ?? "만끽 사용자",
        publicId: row.publicId ?? String(row.userId),
        likeCount: new Set(likes.map(item => item.userId)).size,
        likedByMe: likes.some(item => item.userId === userId),
        comments,
      };
    });
  }

  private async assertCanInteract(userId: number, recordId: number) {
    const db = await this.database();
    const friendIds = await this.friendIds(userId);
    if (!friendIds.length) throw new Error("친구의 기록에만 반응할 수 있습니다.");
    const [record] = await db.select({ id: records.id }).from(records).where(and(eq(records.id, recordId), inArray(records.userId, friendIds))).limit(1);
    if (!record) throw new Error("친구의 기록에만 반응할 수 있습니다.");
  }

  async toggleLike(userId: number, recordId: number) {
    const db = await this.database();
    await this.assertCanInteract(userId, recordId);
    const likeKey = `${userId}:${recordId}`;
    const likePredicate = and(eq(interactions.recordId, recordId), eq(interactions.userId, userId), eq(interactions.type, "like"));
    const [existing] = await db.select({ id: interactions.id }).from(interactions).where(likePredicate).limit(1);
    if (existing) {
      // Also removes old keyless likes left by pre-constraint versions.
      await db.delete(interactions).where(likePredicate);
      return { liked: false };
    }
    try {
      await db.insert(interactions).values({ recordId, userId, type: "like", comment: null, likeKey });
      return { liked: true };
    } catch (error) {
      const code = (error as { code?: string })?.code;
      if (code === "ER_DUP_ENTRY" || String(error).toLowerCase().includes("duplicate")) return { liked: true };
      throw error;
    }
  }

  async addComment(userId: number, recordId: number, comment: string) {
    const db = await this.database();
    await this.assertCanInteract(userId, recordId);
    await db.insert(interactions).values({ recordId, userId, type: "comment", comment });
  }
}
