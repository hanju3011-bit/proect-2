import { and, eq, gt, isNotNull } from "drizzle-orm";
import { nanoid } from "nanoid";
import { getDb } from "../db";
import { DomainError } from "../domain/domain-error";
import { User } from "../domain/user";
import { userSessions, users, type User as UserRow } from "../../drizzle/schema";
import type { FirebaseGoogleIdentity } from "../services/firebase-token-verifier";

export class UserRepository {
  private async database() {
    const db = await getDb();
    if (!db) throw new Error("데이터베이스에 연결할 수 없습니다.");
    return db;
  }

  toDomain(row: UserRow): User {
    return new User(row.id, row.publicId ?? String(row.id), row.email, row.nickname ?? row.name ?? "만끽 사용자", row.profileImg);
  }

  async findById(id: number): Promise<UserRow | null> {
    const db = await this.database();
    const [row] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return row ?? null;
  }

  async findByFirebaseUid(firebaseUid: string): Promise<UserRow | null> {
    const db = await this.database();
    const [row] = await db.select().from(users).where(eq(users.firebaseUid, firebaseUid)).limit(1);
    return row ?? null;
  }

  async findDomainById(id: number): Promise<User | null> {
    const row = await this.findById(id);
    return row ? this.toDomain(row) : null;
  }

  async findPasswordAccountByEmail(email: string): Promise<UserRow | null> {
    const db = await this.database();
    const [row] = await db.select().from(users).where(and(eq(users.authEmail, email), isNotNull(users.passwordHash))).limit(1);
    return row ?? null;
  }

  async findOrCreateFirebaseUser(identity: FirebaseGoogleIdentity): Promise<User> {
    const db = await this.database();
    const existing = await this.findByFirebaseUid(identity.uid);
    if (existing) {
      await db.update(users).set({ email: identity.email, loginMethod: "firebase-google", lastSignedIn: new Date() })
        .where(eq(users.id, existing.id));
      const refreshed = await this.findById(existing.id);
      if (!refreshed) throw new Error("사용자 계정을 찾을 수 없습니다.");
      return this.toDomain(refreshed);
    }

    const publicId = `m${nanoid(9).toLowerCase()}`;
    const displayName = identity.name?.trim().replace(/\s+/g, " ").slice(0, 24);
    const emailName = identity.email.split("@", 1)[0]?.trim().replace(/\s+/g, " ").slice(0, 24);
    const nickname = displayName && displayName.length >= 2 ? displayName : emailName && emailName.length >= 2 ? emailName : "만끽 사용자";

    try {
      const [inserted] = await db.insert(users).values({
        openId: `fb-${publicId}`,
        firebaseUid: identity.uid,
        email: identity.email,
        authEmail: null,
        nickname,
        name: identity.name ?? nickname,
        publicId,
        passwordHash: null,
        profileImg: identity.picture,
        loginMethod: "firebase-google",
        role: "user",
        lastSignedIn: new Date(),
      }).$returningId();
      const row = inserted?.id ? await this.findById(inserted.id) : null;
      if (!row) throw new Error("Google 계정을 저장하지 못했습니다.");
      return this.toDomain(row);
    } catch (error) {
      const errorText = String(error);
      if (/duplicate/i.test(errorText) && /(firebaseUid|firebase_uid)/i.test(errorText)) {
        const concurrent = await this.findByFirebaseUid(identity.uid);
        if (concurrent) return this.toDomain(concurrent);
      }
      throw error;
    }
  }

  async createSession(userId: number, tokenHash: string, expiresAt: Date): Promise<void> {
    const db = await this.database();
    await db.insert(userSessions).values({ userId, tokenHash, expiresAt });
  }

  async findSessionUser(tokenHash: string): Promise<User | null> {
    const db = await this.database();
    const now = new Date();
    const [session] = await db.select({ userId: userSessions.userId }).from(userSessions)
      .where(and(eq(userSessions.tokenHash, tokenHash), gt(userSessions.expiresAt, now))).limit(1);
    if (!session) return null;
    return this.findDomainById(session.userId);
  }

  async deleteSession(tokenHash: string): Promise<void> {
    const db = await this.database();
    await db.delete(userSessions).where(eq(userSessions.tokenHash, tokenHash));
  }

  async updateProfile(userId: number, input: { nickname: string; profileImg?: string | null }): Promise<User> {
    const db = await this.database();
    const current = await this.findById(userId);
    if (!current) throw new DomainError("사용자 계정을 찾을 수 없습니다.");
    const domainUser = this.toDomain(current).updateProfile(input);
    await db.update(users).set({ nickname: domainUser.nickname, name: domainUser.nickname, profileImg: domainUser.profileImg, updatedAt: new Date() })
      .where(eq(users.id, userId));
    return domainUser;
  }
}
