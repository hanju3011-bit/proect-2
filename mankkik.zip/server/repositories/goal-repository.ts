import { eq } from "drizzle-orm";
import { goals, type GoalRow } from "../../drizzle/schema";
import { getDb } from "../db";
import type { Goal } from "../domain/goal";

export class GoalRepository {
  private async database() {
    const db = await getDb();
    if (!db) throw new Error("데이터베이스에 연결할 수 없습니다.");
    return db;
  }

  async listForUser(userId: number): Promise<GoalRow[]> {
    const db = await this.database();
    return db.select().from(goals).where(eq(goals.userId, userId)).orderBy(goals.createdAt);
  }

  async findForUser(goalId: number, userId: number): Promise<GoalRow | null> {
    const db = await this.database();
    const [goal] = await db.select().from(goals).where(eq(goals.id, goalId)).limit(1);
    return goal?.userId === userId ? goal : null;
  }

  async create(goal: Goal): Promise<GoalRow> {
    const db = await this.database();
    const [inserted] = await db.insert(goals).values({
      userId: goal.userId,
      title: goal.title,
      category: goal.category,
      targetAmount: goal.targetAmount,
      currentAmount: 0,
      isUnlimited: goal.isUnlimited,
      startDate: goal.startDate,
      endDate: goal.endDate,
    }).$returningId();
    const [created] = inserted?.id ? await db.select().from(goals).where(eq(goals.id, inserted.id)).limit(1) : [];
    if (!created) throw new Error("목표를 저장하지 못했습니다.");
    return created;
  }
}
