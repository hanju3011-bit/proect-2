import { and, desc, eq, gte, lt, sql } from "drizzle-orm";
import { goals, records, type RecordRow } from "../../drizzle/schema";
import { getDb } from "../db";
import type { ConsumptionRecord } from "../domain/consumption-record";

export class ConsumptionRepository {
  private async database() {
    const db = await getDb();
    if (!db) throw new Error("데이터베이스에 연결할 수 없습니다.");
    return db;
  }

  async listForUser(userId: number, limit = 50, offset = 0) {
    const db = await this.database();
    return db.select({
      id: records.id,
      userId: records.userId,
      goalId: records.goalId,
      amount: records.amount,
      category: records.category,
      memo: records.memo,
      imageUrl: records.imageUrl,
      spentAt: records.spentAt,
      createdAt: records.createdAt,
      goalTitle: goals.title,
    }).from(records)
      .leftJoin(goals, eq(records.goalId, goals.id))
      .where(eq(records.userId, userId))
      .orderBy(desc(records.spentAt), desc(records.id))
      .limit(Math.min(Math.max(limit, 1), 100))
      .offset(Math.max(0, offset));
  }

  async monthSummary(userId: number, startAt: Date, endBefore: Date) {
    const db = await this.database();
    const [summary] = await db.select({
      total: sql<number>`coalesce(sum(${records.amount}), 0)`,
      count: sql<number>`count(*)`,
    }).from(records).where(and(
      eq(records.userId, userId),
      gte(records.spentAt, startAt),
      lt(records.spentAt, endBefore),
    ));
    return { total: Number(summary?.total ?? 0), count: Number(summary?.count ?? 0) };
  }

  async create(record: ConsumptionRecord): Promise<RecordRow> {
    const db = await this.database();
    return db.transaction(async tx => {
      if (record.goalId !== null) {
        const [ownedGoal] = await tx.select({ id: goals.id }).from(goals)
          .where(and(eq(goals.id, record.goalId), eq(goals.userId, record.userId))).limit(1);
        if (!ownedGoal) throw new Error("연결한 목표를 찾을 수 없습니다.");
      }
      const [inserted] = await tx.insert(records).values({
        userId: record.userId,
        goalId: record.goalId,
        amount: record.amount,
        category: record.category,
        memo: record.memo || null,
        imageUrl: record.imageUrl,
        spentAt: record.spentAt,
      }).$returningId();
      if (!inserted?.id) throw new Error("소비 기록을 저장하지 못했습니다.");
      if (record.goalId !== null) {
        await tx.update(goals)
          .set({ currentAmount: sql`${goals.currentAmount} + ${record.amount}`, updatedAt: new Date() })
          .where(and(eq(goals.id, record.goalId), eq(goals.userId, record.userId)));
      }
      const [created] = await tx.select().from(records).where(eq(records.id, inserted.id)).limit(1);
      if (!created) throw new Error("저장된 소비 기록을 불러오지 못했습니다.");
      return created;
    });
  }
}
