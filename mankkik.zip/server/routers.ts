import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { APP_SESSION_COOKIE, getAppSessionToken } from "./auth-session";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { authService } from "./services/auth-service";
import { consumptionService } from "./services/consumption-service";
import { goalService } from "./services/goal-service";
import { photoService } from "./services/photo-service";
import { socialService } from "./services/social-service";
import { UserRepository } from "./repositories/user-repository";
import { throwAsTrpc } from "./services/domain-errors";

const users = new UserRepository();
const publicUser = (user: NonNullable<Parameters<typeof toPublicUser>[0]>) => toPublicUser(user);
function toPublicUser(user: { id: number; publicId?: string | null; email?: string | null; nickname?: string | null; name?: string | null; profileImg?: string | null }) {
  return {
    id: user.id,
    publicId: user.publicId ?? String(user.id),
    email: user.email ?? null,
    nickname: user.nickname ?? user.name ?? "만끽 사용자",
    profileImg: user.profileImg ?? null,
  };
}

function setSessionCookie(ctx: { req: Parameters<typeof getSessionCookieOptions>[0]; res: import("express").Response }, token: string) {
  ctx.res.cookie(APP_SESSION_COOKIE, token, { ...getSessionCookieOptions(ctx.req), maxAge: 1000 * 60 * 60 * 24 * 30 });
}

const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user ? publicUser(ctx.user) : null),
    firebaseLogin: publicProcedure.input(z.object({ idToken: z.string().min(1).max(16_384) })).mutation(async ({ ctx, input }) => {
      try {
        const session = await authService.loginWithGoogleToken(input.idToken);
        setSessionCookie(ctx, session.token);
        return publicUser(session.user.toPublicProfile());
      } catch (error) { return throwAsTrpc(error); }
    }),
    login: publicProcedure.input(z.object({
      email: z.string().trim().email().max(320),
      password: z.string().min(1).max(128),
    })).mutation(async ({ ctx, input }) => {
      try {
        const session = await authService.login(input.email, input.password);
        setSessionCookie(ctx, session.token);
        return publicUser(session.user.toPublicProfile());
      } catch (error) { return throwAsTrpc(error); }
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      try { await authService.revokeToken(getAppSessionToken(ctx.req)); }
      finally { ctx.res.clearCookie(APP_SESSION_COOKIE, { ...getSessionCookieOptions(ctx.req), maxAge: 0 }); }
      return { success: true as const };
    }),
  }),

  profile: router({
    update: protectedProcedure.input(z.object({
      nickname: z.string().trim().min(2).max(24),
      profileImg: z.string().max(2048).refine(value => value.startsWith("/manus-storage/") || value.startsWith("https://"), "프로필 이미지 주소가 올바르지 않습니다.").nullable().optional(),
    })).mutation(async ({ ctx, input }) => {
      try { return (await users.updateProfile(ctx.user.id, input)).toPublicProfile(); }
      catch (error) { return throwAsTrpc(error); }
    }),
  }),

  media: router({
    upload: protectedProcedure.input(z.object({
      purpose: z.enum(["profile", "record"]),
      dataUrl: z.string().min(32).max(7_100_000),
    })).mutation(async ({ ctx, input }) => {
      try { return { url: await photoService.upload(ctx.user.id, input.purpose, input.dataUrl) }; }
      catch (error) { return throwAsTrpc(error); }
    }),
  }),

  goals: router({
    list: protectedProcedure.query(({ ctx }) => goalService.list(ctx.user.id)),
    create: protectedProcedure.input(z.object({
      title: z.string().trim().min(1).max(80),
      category: z.string().trim().min(1).max(40),
      targetAmount: z.number().int().positive().max(1_000_000_000),
      isUnlimited: z.boolean(),
      startDate: z.coerce.date(),
      endDate: z.coerce.date().nullable(),
    })).mutation(async ({ ctx, input }) => {
      try { return await goalService.create(ctx.user.id, input); }
      catch (error) { return throwAsTrpc(error); }
    }),
  }),

  records: router({
    list: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(100).default(50), offset: z.number().int().min(0).max(10_000_000).default(0) }).optional())
      .query(({ ctx, input }) => consumptionService.list(ctx.user.id, input?.limit ?? 50, input?.offset ?? 0)),
    summary: protectedProcedure.input(z.object({ startAt: z.coerce.date(), endBefore: z.coerce.date() }))
      .query(({ ctx, input }) => consumptionService.summary(ctx.user.id, input.startAt, input.endBefore)),
    create: protectedProcedure.input(z.object({
      goalId: z.number().int().positive().nullable(),
      amount: z.number().int().positive().max(1_000_000_000),
      category: z.string().trim().min(1).max(40),
      memo: z.string().max(500).default(""),
      imageUrl: z.string().max(2048).refine(value => value.startsWith("/manus-storage/") || value.startsWith("https://"), "이미지 주소가 올바르지 않습니다.").nullable(),
      spentAt: z.coerce.date(),
    })).mutation(async ({ ctx, input }) => {
      try { return await consumptionService.create(ctx.user.id, input); }
      catch (error) { return throwAsTrpc(error); }
    }),
  }),

  social: router({
    search: protectedProcedure.input(z.object({ query: z.string().trim().min(1).max(64) }))
      .query(({ ctx, input }) => socialService.search(ctx.user.id, input.query)),
    sendRequest: protectedProcedure.input(z.object({ receiverId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => socialService.sendRequest(ctx.user.id, input.receiverId).catch(error => throwAsTrpc(error))),
    requests: protectedProcedure.query(({ ctx }) => socialService.listRequests(ctx.user.id)),
    respond: protectedProcedure.input(z.object({ requesterId: z.number().int().positive(), accept: z.boolean() }))
      .mutation(({ ctx, input }) => socialService.respond(ctx.user.id, input.requesterId, input.accept).catch(error => throwAsTrpc(error))),
    friends: protectedProcedure.query(({ ctx }) => socialService.listFriends(ctx.user.id)),
    feed: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(50).default(30) }).optional())
      .query(({ ctx, input }) => socialService.feed(ctx.user.id, input?.limit ?? 30)),
    toggleLike: protectedProcedure.input(z.object({ recordId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => socialService.toggleLike(ctx.user.id, input.recordId).catch(error => throwAsTrpc(error))),
    comment: protectedProcedure.input(z.object({ recordId: z.number().int().positive(), comment: z.string().trim().min(1).max(500) }))
      .mutation(({ ctx, input }) => socialService.comment(ctx.user.id, input.recordId, input.comment).catch(error => throwAsTrpc(error))),
  }),
});

export { appRouter };
export type AppRouter = typeof appRouter;
