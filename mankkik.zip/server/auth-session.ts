import type { Request } from "express";
import { parse } from "cookie";

export const APP_SESSION_COOKIE = "mankkik_session";

export function getAppSessionToken(req: Request): string | null {
  const raw = req.headers.cookie;
  if (!raw) return null;
  try {
    return parse(raw)[APP_SESSION_COOKIE] ?? null;
  } catch {
    return null;
  }
}
