import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { APP_SESSION_COOKIE } from "./auth-session";
import type { TrpcContext } from "./_core/context";

type CookieCall = { name: string; options: Record<string, unknown> };
type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: CookieCall[] } {
  const clearedCookies: CookieCall[] = [];
  const user = {
    id: 1,
    openId: "local-mtestid",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "email-password",
    role: "user" as const,
    nickname: "Sample User",
    publicId: "mtestid",
    passwordHash: null,
    profileImg: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } satisfies AuthenticatedUser;
  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: (name: string, options: Record<string, unknown>) => { clearedCookies.push({ name, options }); } } as TrpcContext["res"],
  };
  return { ctx, clearedCookies };
}

describe("auth.logout", () => {
  it("clears the app-owned session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const result = await appRouter.createCaller(ctx).auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(APP_SESSION_COOKIE);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: 0, secure: true, sameSite: "none", httpOnly: true, path: "/" });
  });
});
