import { TRPCError } from "@trpc/server";
import { DomainError } from "../domain/domain-error";

export function throwAsTrpc(error: unknown): never {
  if (error instanceof DomainError) throw new TRPCError({ code: "BAD_REQUEST", message: error.message });
  throw error;
}
