import { photoStorageService } from "./photo-storage-service";

export class PhotoService {
  upload(userId: number, purpose: "profile" | "record", dataUrl: string) {
    return photoStorageService.upload(userId, purpose, dataUrl);
  }
}

export const photoService = new PhotoService();
