import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";
import { DomainError } from "../domain/domain-error";

const FIREBASE_JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
);

export type FirebaseGoogleIdentity = {
  uid: string;
  email: string;
  name: string | null;
  picture: string | null;
};

export function parseFirebaseGoogleIdentity(payload: JWTPayload): FirebaseGoogleIdentity {
  const providerClaims = payload.firebase as { sign_in_provider?: unknown } | undefined;
  const uid = payload.sub;
  const email = payload.email;
  const name = payload.name;
  const picture = payload.picture;
  const now = Math.floor(Date.now() / 1000);

  if (!uid || uid.length > 128 || typeof email !== "string" || email.length > 320 || payload.email_verified !== true) {
    throw new DomainError("Google 계정의 확인된 이메일 정보를 받지 못했어요. 다시 로그인해 주세요.");
  }
  if (providerClaims?.sign_in_provider !== "google.com") {
    throw new DomainError("Google 계정 로그인으로 다시 시도해 주세요.");
  }
  if (typeof payload.exp !== "number" || payload.exp <= now || typeof payload.iat !== "number" || payload.iat > now + 60 ||
      typeof payload.auth_time !== "number" || payload.auth_time > now + 60) {
    throw new DomainError("Google 로그인 정보가 만료되었어요. 다시 로그인해 주세요.");
  }

  return {
    uid,
    email: email.trim().toLowerCase(),
    name: typeof name === "string" ? name.slice(0, 256) : null,
    picture: typeof picture === "string" && picture.startsWith("https://") && picture.length <= 2048 ? picture : null,
  };
}

export class FirebaseTokenVerifier {
  async verifyGoogleIdToken(idToken: string): Promise<FirebaseGoogleIdentity> {
    const projectId = process.env.FIREBASE_PROJECT_ID?.trim();
    if (!projectId) {
      throw new DomainError("Google 로그인이 아직 설정되지 않았어요. Firebase 웹 앱 설정을 연결해 주세요.");
    }
    if (!idToken || idToken.length > 16_384) {
      throw new DomainError("Google 로그인 정보를 확인하지 못했어요. 다시 시도해 주세요.");
    }

    try {
      const { payload } = await jwtVerify(idToken, FIREBASE_JWKS, {
        algorithms: ["RS256"],
        issuer: `https://securetoken.google.com/${projectId}`,
        audience: projectId,
        clockTolerance: 5,
      });
      return parseFirebaseGoogleIdentity(payload);
    } catch (error) {
      if (error instanceof DomainError) throw error;
      throw new DomainError("Google 로그인 정보를 확인하지 못했어요. 잠시 후 다시 시도해 주세요.");
    }
  }
}

export const firebaseTokenVerifier = new FirebaseTokenVerifier();
