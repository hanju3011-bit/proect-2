import { Goal, type GoalInput } from "../domain/goal";
import { GoalRepository } from "../repositories/goal-repository";

export class GoalService {
  constructor(private readonly goals = new GoalRepository()) {}

  async list(userId: number) {
    const rows = await this.goals.listForUser(userId);
    return rows.map(row => {
      const goal = new Goal(row.id, row.userId, row.title, row.category, row.targetAmount, row.currentAmount, row.isUnlimited, row.startDate, row.endDate);
      return { ...row, progressPercent: goal.progressPercent, remainingAmount: goal.remainingAmount };
    });
  }

  async create(userId: number, input: GoalInput) {
    const goal = Goal.create(userId, input);
    const row = await this.goals.create(goal);
    return { ...row, progressPercent: goal.progressPercent, remainingAmount: goal.remainingAmount };
  }

  async findForUser(goalId: number, userId: number) {
    return this.goals.findForUser(goalId, userId);
  }
}

export const goalService = new GoalService();
