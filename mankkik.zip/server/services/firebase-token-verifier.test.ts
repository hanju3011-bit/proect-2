import { describe, expect, it } from "vitest";
import type { JWTPayload } from "jose";
import { DomainError } from "../domain/domain-error";
import { parseFirebaseGoogleIdentity } from "./firebase-token-verifier";

const now = Math.floor(Date.now() / 1000);
const validPayload = (overrides: Partial<JWTPayload> = {}): JWTPayload => ({
  sub: "firebase-user-uid",
  email: "  person@example.com ",
  email_verified: true,
  name: "만끽 사용자",
  picture: "https://images.example.com/avatar.png",
  firebase: { sign_in_provider: "google.com" },
  exp: now + 600,
  iat: now - 30,
  auth_time: now - 30,
  ...overrides,
});

describe("Firebase Google identity claims", () => {
  it("normalizes verified Google profile claims for account provisioning", () => {
    expect(parseFirebaseGoogleIdentity(validPayload())).toEqual({
      uid: "firebase-user-uid",
      email: "person@example.com",
      name: "만끽 사용자",
      picture: "https://images.example.com/avatar.png",
    });
  });

  it("rejects an unverified email", () => {
    expect(() => parseFirebaseGoogleIdentity(validPayload({ email_verified: false })))
      .toThrowError(DomainError);
  });

  it("rejects tokens from any provider other than Google", () => {
    expect(() => parseFirebaseGoogleIdentity(validPayload({ firebase: { sign_in_provider: "password" } })))
      .toThrowError("Google 계정 로그인으로 다시 시도해 주세요.");
  });

  it("rejects expired identity claims", () => {
    expect(() => parseFirebaseGoogleIdentity(validPayload({ exp: now - 1 })))
      .toThrowError("Google 로그인 정보가 만료되었어요. 다시 로그인해 주세요.");
  });
});
