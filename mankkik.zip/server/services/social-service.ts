import { DomainError } from "../domain/domain-error";
import { Friend } from "../domain/friend";
import { Friendship } from "../domain/friendship";
import { Interaction } from "../domain/interaction";
import { SocialRepository } from "../repositories/social-repository";

export class SocialService {
  constructor(private readonly social = new SocialRepository()) {}

  search(userId: number, query: string) { return this.social.searchUsers(userId, query); }

  async sendRequest(requesterId: number, receiverId: number) {
    Friendship.request(requesterId, receiverId);
    try { await this.social.sendFriendRequest(requesterId, receiverId); }
    catch (error) { throw new DomainError(error instanceof Error ? error.message : "친구 신청을 처리하지 못했습니다."); }
    return { success: true as const };
  }

  async respond(receiverId: number, requesterId: number, accepted: boolean) {
    const pending = new Friendship(null, requesterId, receiverId, "pending");
    const transition = pending.respond(receiverId, accepted);
    try { await this.social.respondToRequest(receiverId, requesterId, transition.status as "accepted" | "rejected"); }
    catch (error) { throw new DomainError(error instanceof Error ? error.message : "친구 신청을 처리하지 못했습니다."); }
    return { success: true as const };
  }

  listRequests(userId: number) { return this.social.listFriendRequests(userId); }

  async listFriends(userId: number) {
    const rows = await this.social.listFriends(userId);
    return rows.map(row => Friend.fromProfile(row).toProfile());
  }

  feed(userId: number, limit = 30) { return this.social.listFeed(userId, limit); }

  async toggleLike(userId: number, recordId: number) {
    Interaction.like(recordId, userId);
    try { return await this.social.toggleLike(userId, recordId); }
    catch (error) { throw new DomainError(error instanceof Error ? error.message : "공감을 처리하지 못했습니다."); }
  }

  async comment(userId: number, recordId: number, rawComment: string) {
    const interaction = Interaction.commentOn(recordId, userId, rawComment);
    try { await this.social.addComment(userId, recordId, interaction.comment ?? ""); }
    catch (error) { throw new DomainError(error instanceof Error ? error.message : "응원 메시지를 남기지 못했습니다."); }
    return { success: true as const };
  }
}

export const socialService = new SocialService();
