import { randomUUID } from "node:crypto";
import { storagePut } from "../storage";
import { DomainError } from "../domain/domain-error";

const MIME_EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

function matchesImageSignature(mimeType: string, bytes: Buffer): boolean {
  if (mimeType === "image/jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (mimeType === "image/png") return bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (mimeType === "image/webp") return bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
  return false;
}

export class PhotoStorageService {
  async upload(userId: number, purpose: "profile" | "record", dataUrl: string): Promise<string> {
    const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl);
    if (!match) throw new DomainError("JPG, PNG 또는 WebP 이미지 파일을 선택해 주세요.");
    const [, mimeType, encoded] = match;
    const bytes = Buffer.from(encoded, "base64");
    if (!bytes.length || bytes.length > MAX_IMAGE_BYTES) throw new DomainError("이미지는 5MB 이하로 업로드해 주세요.");
    if (!matchesImageSignature(mimeType, bytes)) throw new DomainError("파일 내용과 이미지 형식이 일치하지 않습니다.");
    const extension = MIME_EXTENSIONS[mimeType];
    const { url } = await storagePut(`mankkik/${purpose}/${userId}/${randomUUID()}.${extension}`, bytes, mimeType);
    return url;
  }
}

export const photoStorageService = new PhotoStorageService();
