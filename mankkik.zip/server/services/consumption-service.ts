import { DomainError } from "../domain/domain-error";
import { ConsumptionRecord, type ConsumptionRecordInput } from "../domain/consumption-record";
import { ConsumptionRepository } from "../repositories/consumption-repository";
import { GoalService } from "./goal-service";

export class ConsumptionService {
  constructor(
    private readonly records = new ConsumptionRepository(),
    private readonly goals = new GoalService(),
  ) {}

  list(userId: number, limit = 50, offset = 0) {
    return this.records.listForUser(userId, limit, offset);
  }

  summary(userId: number, startAt: Date, endBefore: Date) {
    return this.records.monthSummary(userId, startAt, endBefore);
  }

  async create(userId: number, input: ConsumptionRecordInput) {
    const record = ConsumptionRecord.create(userId, input);
    if (record.goalId !== null) {
      const goal = await this.goals.findForUser(record.goalId, userId);
      if (!goal) throw new DomainError("연결한 목표를 찾을 수 없습니다.");
      if (record.spentAt < goal.startDate || (goal.endDate && record.spentAt > goal.endDate)) {
        throw new DomainError("지출 날짜가 목표 기간에 포함되지 않습니다.");
      }
    }
    try {
      return await this.records.create(record);
    } catch (error) {
      if (String(error).includes("연결한 목표")) throw new DomainError("연결한 목표를 찾을 수 없습니다.");
      throw error;
    }
  }
}

export const consumptionService = new ConsumptionService();
