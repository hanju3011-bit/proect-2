import { createHash, randomBytes } from "node:crypto";
import { DomainError } from "../domain/domain-error";
import { User } from "../domain/user";
import { PasswordHasher } from "../security/password-hasher";
import { UserRepository } from "../repositories/user-repository";
import { firebaseTokenVerifier } from "./firebase-token-verifier";

const SESSION_LIFETIME_MS = 1000 * 60 * 60 * 24 * 30;
const sessionHash = (token: string) => createHash("sha256").update(token).digest("hex");

export class AuthService {
  constructor(
    private readonly users = new UserRepository(),
    private readonly passwords = new PasswordHasher(),
  ) {}

  private async issueSession(user: User): Promise<{ user: User; token: string; expiresAt: Date }> {
    const token = randomBytes(32).toString("base64url");
    const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS);
    await this.users.createSession(user.id, sessionHash(token), expiresAt);
    return { user, token, expiresAt };
  }

  async login(emailInput: string, password: string) {
    const email = emailInput.trim().toLowerCase();
    const row = await this.users.findPasswordAccountByEmail(email);
    if (!row?.passwordHash || !(await this.passwords.verify(password, row.passwordHash))) {
      throw new DomainError("이메일 또는 비밀번호를 확인해 주세요.");
    }
    return this.issueSession(this.users.toDomain(row));
  }

  async loginWithGoogleToken(idToken: string) {
    const identity = await firebaseTokenVerifier.verifyGoogleIdToken(idToken);
    const user = await this.users.findOrCreateFirebaseUser(identity);
    return this.issueSession(user);
  }

  async userFromToken(token: string | null | undefined): Promise<User | null> {
    if (!token || token.length > 256) return null;
    return this.users.findSessionUser(sessionHash(token));
  }

  async revokeToken(token: string | null | undefined): Promise<void> {
    if (!token || token.length > 256) return;
    await this.users.deleteSession(sessionHash(token));
  }
}

export const authService = new AuthService();
