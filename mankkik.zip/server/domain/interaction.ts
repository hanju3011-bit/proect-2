import { DomainError } from "./domain-error";

export type InteractionType = "like" | "comment";

export class Interaction {
  constructor(
    readonly id: number | null,
    readonly recordId: number,
    readonly userId: number,
    readonly type: InteractionType,
    readonly comment: string | null,
  ) {}

  static like(recordId: number, userId: number): Interaction {
    if (recordId <= 0) throw new DomainError("기록을 찾을 수 없습니다.");
    return new Interaction(null, recordId, userId, "like", null);
  }

  static commentOn(recordId: number, userId: number, rawComment: string): Interaction {
    const comment = rawComment.trim();
    if (recordId <= 0) throw new DomainError("기록을 찾을 수 없습니다.");
    if (!comment || comment.length > 500) throw new DomainError("응원 메시지는 1자 이상 500자 이하로 입력해 주세요.");
    return new Interaction(null, recordId, userId, "comment", comment);
  }
}
