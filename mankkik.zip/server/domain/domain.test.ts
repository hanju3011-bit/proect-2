import { describe, expect, it } from "vitest";
import { ConsumptionRecord } from "./consumption-record";
import { Friend } from "./friend";
import { Friendship } from "./friendship";
import { Goal } from "./goal";
import { Interaction } from "./interaction";
import { User } from "./user";
import { PasswordHasher } from "../security/password-hasher";

const date = (value: string) => new Date(`${value}T00:00:00`);

describe("domain models", () => {
  it("normalizes and validates email registration and profile values", () => {
    expect(User.validateRegistration({ email: "  PERSON@EXAMPLE.COM ", nickname: "민지", password: "password123" })).toEqual({ email: "person@example.com", nickname: "민지" });
    expect(() => User.validateRegistration({ email: "bad", nickname: "민지", password: "password123" })).toThrow();
  });

  it("supports unlimited goals and derives capped progress and remaining budget", () => {
    const goal = Goal.create(1, { title: "카페 지출", category: "카페", targetAmount: 100_000, isUnlimited: true, startDate: date("2026-10-01"), endDate: null });
    expect(goal.isUnlimited).toBe(true);
    expect(goal.progressPercent).toBe(0);
    const progressed = goal.addConsumption(35_000);
    expect(progressed.progressPercent).toBe(35);
    expect(progressed.remainingAmount).toBe(65_000);
    expect(goal.addConsumption(110_000).progressPercent).toBe(100);
    expect(() => Goal.create(1, { title: "기간형", category: "생활", targetAmount: 20_000, isUnlimited: false, startDate: date("2026-10-10"), endDate: date("2026-10-01") })).toThrow();
  });

  it("validates consumption records before they reach the repository", () => {
    const record = ConsumptionRecord.create(1, { goalId: null, amount: 4_500, category: "카페", memo: "라테", imageUrl: null, spentAt: date("2026-10-14") });
    expect(record.amount).toBe(4_500);
    expect(record.memo).toBe("라테");
    expect(() => ConsumptionRecord.create(1, { goalId: null, amount: 0, category: "카페", memo: "", imageUrl: null, spentAt: date("2026-10-14") })).toThrow();
  });

  it("allows a recipient to accept a pending friendship and prevents self-requests", () => {
    const request = Friendship.request(1, 2);
    expect(request.respond(2, true).status).toBe("accepted");
    expect(() => Friendship.request(1, 1)).toThrow();
    expect(() => request.respond(1, true)).toThrow();
  });

  it("creates validated likes and non-empty encouragement comments", () => {
    expect(Interaction.like(3, 1).type).toBe("like");
    expect(Interaction.commentOn(3, 1, "  응원해!  ").comment).toBe("응원해!");
    expect(() => Interaction.commentOn(3, 1, "   ")).toThrow();
  });

  it("normalizes friend profile rows into the Friend model", () => {
    expect(Friend.fromProfile({ id: 9, publicId: null, nickname: null, profileImg: null, }).toProfile()).toEqual({ id: 9, publicId: "9", nickname: "만끽 사용자", profileImg: null });
  });

  it("stores passwords as one-way hashes and verifies only the matching password", async () => {
    const passwords = new PasswordHasher();
    const stored = await passwords.hash("private-passphrase");
    expect(stored).not.toContain("private-passphrase");
    expect(await passwords.verify("private-passphrase", stored)).toBe(true);
    expect(await passwords.verify("wrong-passphrase", stored)).toBe(false);
  });
});
