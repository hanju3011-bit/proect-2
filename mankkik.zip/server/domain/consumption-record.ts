import { DomainError } from "./domain-error";

export type ConsumptionRecordInput = {
  goalId: number | null;
  amount: number;
  category: string;
  memo: string;
  imageUrl: string | null;
  spentAt: Date;
};

export class ConsumptionRecord {
  constructor(
    readonly id: number | null,
    readonly userId: number,
    readonly goalId: number | null,
    readonly amount: number,
    readonly category: string,
    readonly memo: string,
    readonly imageUrl: string | null,
    readonly spentAt: Date,
  ) {}

  static create(userId: number, input: ConsumptionRecordInput): ConsumptionRecord {
    const category = input.category.trim();
    const memo = input.memo.trim();
    if (!Number.isSafeInteger(input.amount) || input.amount <= 0 || input.amount > 1_000_000_000) {
      throw new DomainError("소비 금액은 1원 이상 10억 원 이하로 입력해 주세요.");
    }
    if (!category || category.length > 40) throw new DomainError("카테고리를 선택해 주세요.");
    if (memo.length > 500) throw new DomainError("메모는 500자 이하로 작성해 주세요.");
    if (Number.isNaN(input.spentAt.getTime())) throw new DomainError("지출 날짜를 확인해 주세요.");
    return new ConsumptionRecord(null, userId, input.goalId, input.amount, category, memo, input.imageUrl, input.spentAt);
  }
}
