export class Friend {
  constructor(
    readonly id: number,
    readonly publicId: string,
    readonly nickname: string,
    readonly profileImg: string | null,
  ) {}

  static fromProfile(input: { id: number; publicId: string | null; nickname: string | null; profileImg: string | null }): Friend {
    return new Friend(input.id, input.publicId ?? String(input.id), input.nickname?.trim() || "만끽 사용자", input.profileImg);
  }

  toProfile() {
    return { id: this.id, publicId: this.publicId, nickname: this.nickname, profileImg: this.profileImg };
  }
}
