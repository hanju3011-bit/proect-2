import { DomainError } from "./domain-error";

export type FriendshipStatus = "pending" | "accepted" | "rejected";

export class Friendship {
  constructor(
    readonly id: number | null,
    readonly requesterId: number,
    readonly receiverId: number,
    readonly status: FriendshipStatus,
  ) {}

  static request(requesterId: number, receiverId: number): Friendship {
    if (requesterId === receiverId) throw new DomainError("나 자신에게 친구 신청을 보낼 수 없습니다.");
    if (!Number.isInteger(receiverId) || receiverId <= 0) throw new DomainError("친구를 찾을 수 없습니다.");
    return new Friendship(null, requesterId, receiverId, "pending");
  }

  respond(actorId: number, accepted: boolean): Friendship {
    if (this.receiverId !== actorId || this.status !== "pending") throw new DomainError("이 친구 신청을 처리할 수 없습니다.");
    return new Friendship(this.id, this.requesterId, this.receiverId, accepted ? "accepted" : "rejected");
  }
}
