import { DomainError } from "./domain-error";

export type PublicUserProfile = {
  id: number;
  publicId: string;
  email: string | null;
  nickname: string;
  profileImg: string | null;
};

export class User {
  constructor(
    readonly id: number,
    readonly publicId: string,
    readonly email: string | null,
    readonly nickname: string,
    readonly profileImg: string | null,
  ) {}

  static validateRegistration(input: { email: string; nickname: string; password: string }) {
    const email = input.email.trim().toLowerCase();
    const nickname = input.nickname.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new DomainError("올바른 이메일 주소를 입력해 주세요.");
    if (nickname.length < 2 || nickname.length > 24) throw new DomainError("닉네임은 2자 이상 24자 이하로 입력해 주세요.");
    if (input.password.length < 8 || input.password.length > 128) throw new DomainError("비밀번호는 8자 이상 128자 이하로 입력해 주세요.");
    return { email, nickname };
  }

  updateProfile(input: { nickname: string; profileImg?: string | null }): User {
    const nickname = input.nickname.trim();
    if (nickname.length < 2 || nickname.length > 24) throw new DomainError("닉네임은 2자 이상 24자 이하로 입력해 주세요.");
    return new User(this.id, this.publicId, this.email, nickname, input.profileImg === undefined ? this.profileImg : input.profileImg);
  }

  toPublicProfile(): PublicUserProfile {
    return { id: this.id, publicId: this.publicId, email: this.email, nickname: this.nickname, profileImg: this.profileImg };
  }
}
