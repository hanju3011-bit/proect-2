import { DomainError } from "./domain-error";

export type GoalInput = {
  title: string;
  category: string;
  targetAmount: number;
  isUnlimited: boolean;
  startDate: Date;
  endDate: Date | null;
};

export class Goal {
  constructor(
    readonly id: number | null,
    readonly userId: number,
    readonly title: string,
    readonly category: string,
    readonly targetAmount: number,
    readonly currentAmount: number,
    readonly isUnlimited: boolean,
    readonly startDate: Date,
    readonly endDate: Date | null,
  ) {}

  static create(userId: number, input: GoalInput): Goal {
    const title = input.title.trim();
    const category = input.category.trim();
    if (!title || title.length > 80) throw new DomainError("목표 이름은 1자 이상 80자 이하로 입력해 주세요.");
    if (!category || category.length > 40) throw new DomainError("목표 카테고리를 선택해 주세요.");
    if (!Number.isSafeInteger(input.targetAmount) || input.targetAmount <= 0 || input.targetAmount > 1_000_000_000) {
      throw new DomainError("목표 금액은 1원 이상 10억 원 이하로 입력해 주세요.");
    }
    if (Number.isNaN(input.startDate.getTime())) throw new DomainError("시작일을 확인해 주세요.");
    if (input.isUnlimited && input.endDate) throw new DomainError("무제한 기간 목표는 종료일을 지정하지 않습니다.");
    if (!input.isUnlimited && !input.endDate) throw new DomainError("기간형 목표에는 종료일이 필요합니다.");
    if (input.endDate && input.endDate < input.startDate) throw new DomainError("종료일은 시작일보다 빠를 수 없습니다.");
    return new Goal(null, userId, title, category, input.targetAmount, 0, input.isUnlimited, input.startDate, input.endDate);
  }

  get progressPercent(): number {
    return this.targetAmount > 0 ? Math.min(100, Math.round((this.currentAmount / this.targetAmount) * 100)) : 0;
  }

  get remainingAmount(): number {
    return Math.max(0, this.targetAmount - this.currentAmount);
  }

  addConsumption(amount: number): Goal {
    if (!Number.isSafeInteger(amount) || amount <= 0) throw new DomainError("소비 금액은 1원 이상이어야 합니다.");
    return new Goal(this.id, this.userId, this.title, this.category, this.targetAmount, this.currentAmount + amount, this.isUnlimited, this.startDate, this.endDate);
  }
}
