import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User as UserRow } from "../../drizzle/schema";
import { authService } from "../services/auth-service";
import { getAppSessionToken } from "../auth-session";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: UserRow | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: UserRow | null = null;
  try {
    const localUser = await authService.userFromToken(getAppSessionToken(opts.req));
    if (localUser) {
      user = {
        id: localUser.id,
        openId: `local-${localUser.publicId}`,
        name: localUser.nickname,
        email: localUser.email,
        loginMethod: "app-session",
        role: "user",
        nickname: localUser.nickname,
        publicId: localUser.publicId,
        passwordHash: null,
        profileImg: localUser.profileImg,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      } as UserRow;
    }
  } catch (error) {
    console.error("[Auth] Application session lookup failed:", error);
  }

  return { req: opts.req, res: opts.res, user };
}
