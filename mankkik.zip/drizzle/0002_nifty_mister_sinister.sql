ALTER TABLE `interactions` ADD `likeKey` varchar(64);--> statement-breakpoint
ALTER TABLE `interactions` ADD CONSTRAINT `interactions_like_key_unique` UNIQUE(`likeKey`);