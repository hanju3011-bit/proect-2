ALTER TABLE `users` DROP INDEX `users_email_unique`;--> statement-breakpoint
ALTER TABLE `users` ADD `authEmail` varchar(320);--> statement-breakpoint
UPDATE `users` SET `authEmail` = `email` WHERE `passwordHash` IS NOT NULL AND `email` IS NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_authEmail_unique` UNIQUE(`authEmail`);
