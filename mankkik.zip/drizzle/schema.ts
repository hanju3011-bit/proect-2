import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Application accounts. Password hashes are nullable for legacy Manus OAuth rows. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  firebaseUid: varchar("firebaseUid", { length: 128 }),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  authEmail: varchar("authEmail", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  nickname: varchar("nickname", { length: 64 }),
  publicId: varchar("publicId", { length: 20 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  profileImg: varchar("profileImg", { length: 2048 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, table => ({
  firebaseUidUnique: uniqueIndex("users_firebaseUid_unique").on(table.firebaseUid),
  authEmailUnique: uniqueIndex("users_authEmail_unique").on(table.authEmail),
  publicIdUnique: uniqueIndex("users_publicId_unique").on(table.publicId),
}));

export const userSessions = mysqlTable("userSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ userSessionIndex: index("userSessions_userId_idx").on(table.userId) }));

export const goals = mysqlTable("goals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 80 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  targetAmount: int("targetAmount").notNull(),
  currentAmount: int("currentAmount").default(0).notNull(),
  isUnlimited: boolean("isUnlimited").default(false).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ userGoalIndex: index("goals_userId_idx").on(table.userId) }));

export const records = mysqlTable("records", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  goalId: int("goalId").references(() => goals.id, { onDelete: "set null" }),
  amount: int("amount").notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  memo: text("memo"),
  imageUrl: varchar("imageUrl", { length: 2048 }),
  spentAt: timestamp("spentAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  recordOwnerDateIndex: index("records_user_spentAt_idx").on(table.userId, table.spentAt),
  recordGoalIndex: index("records_goalId_idx").on(table.goalId),
}));

export const friendships = mysqlTable("friendships", {
  id: int("id").autoincrement().primaryKey(),
  requesterId: int("requesterId").notNull().references(() => users.id, { onDelete: "cascade" }),
  receiverId: int("receiverId").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: mysqlEnum("status", ["pending", "accepted", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  friendshipPairUnique: uniqueIndex("friendships_pair_unique").on(table.requesterId, table.receiverId),
  receiverStatusIndex: index("friendships_receiver_status_idx").on(table.receiverId, table.status),
}));

export const interactions = mysqlTable("interactions", {
  id: int("id").autoincrement().primaryKey(),
  recordId: int("recordId").notNull().references(() => records.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: mysqlEnum("type", ["like", "comment"]).notNull(),
  comment: varchar("comment", { length: 500 }),
  likeKey: varchar("likeKey", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  uniqueLikeKey: uniqueIndex("interactions_like_key_unique").on(table.likeKey),
  recordInteractionsIndex: index("interactions_record_type_idx").on(table.recordId, table.type),
  userInteractionsIndex: index("interactions_user_record_idx").on(table.userId, table.recordId),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type GoalRow = typeof goals.$inferSelect;
export type RecordRow = typeof records.$inferSelect;
export type FriendshipRow = typeof friendships.$inferSelect;
export type InteractionRow = typeof interactions.$inferSelect;
