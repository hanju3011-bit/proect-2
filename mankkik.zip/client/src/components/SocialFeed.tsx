import { useState, type FormEvent } from "react";
import { ArrowUpRight, Heart, MessageCircle, Send } from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";

type FeedPost = inferRouterOutputs<AppRouter>["social"]["feed"][number];
const money = (value: number) => `${new Intl.NumberFormat("ko-KR").format(value)}원`;
const dateLabel = (value: Date | string) => new Intl.DateTimeFormat("ko-KR", { month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value));

function Avatar({ nickname, image, size = "md" }: { nickname: string; image?: string | null; size?: "sm" | "md" | "lg" }) {
  return <span className={`avatar avatar-${size}`}>{image ? <img src={image} alt={`${nickname} 프로필`} /> : nickname.slice(0, 1)}</span>;
}

function FeedCard({ post, onChanged }: { post: FeedPost; onChanged: () => void }) {
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const like = trpc.social.toggleLike.useMutation();
  const addComment = trpc.social.comment.useMutation();
  const submitComment = async (event: FormEvent) => {
    event.preventDefault();
    if (!comment.trim()) return;
    setError("");
    try {
      await addComment.mutateAsync({ recordId: post.id, comment });
      setComment("");
      await utils.social.feed.invalidate();
      onChanged();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "메시지를 보내지 못했어요."); }
  };

  return <article className="feed-card">
    <header className="feed-card-head">
      <Avatar nickname={post.nickname} image={post.profileImg} />
      <div className="feed-author"><strong>{post.nickname}</strong><span>@{post.publicId} <i>·</i> {dateLabel(post.spentAt)}</span></div>
      <span className="feed-category">{post.category}</span>
    </header>
    <div className="feed-money-row"><span className="feed-amount">{money(post.amount)}</span>{post.goalTitle && <span className="feed-goal">목표 · {post.goalTitle}</span>}</div>
    {post.memo && <p className="feed-memo">{post.memo}</p>}
    {post.imageUrl && <div className="feed-image-wrap"><img src={post.imageUrl} alt={`${post.nickname}님의 소비 기록 사진`} loading="lazy" /></div>}
    <div className="feed-action-row">
      <button className={`feed-action${post.likedByMe ? " is-liked" : ""}`} onClick={async () => { try { await like.mutateAsync({ recordId: post.id }); await utils.social.feed.invalidate(); onChanged(); } catch (cause) { setError(cause instanceof Error ? cause.message : "공감을 보내지 못했어요."); } }} disabled={like.isPending} aria-label={post.likedByMe ? "공감 취소" : "공감 보내기"}>
        <Heart size={17} fill={post.likedByMe ? "currentColor" : "none"} /><span>{post.likeCount || "공감"}</span>
      </button>
      <span className="feed-action-static"><MessageCircle size={17} /><span>{post.comments.length || "응원"}</span></span>
      <span className="feed-spacer" />
      <span className="support-note"><ArrowUpRight size={14} /> 함께 응원해요</span>
    </div>
    {post.comments.length > 0 && <div className="feed-comments">{post.comments.slice(-3).map(item => <p key={item.id}><strong>{item.nickname}</strong><span>{item.comment}</span></p>)}</div>}
    <form className="comment-form" onSubmit={submitComment}>
      <input aria-label="응원 댓글" placeholder="따뜻한 한마디를 남겨보세요" value={comment} onChange={event => setComment(event.target.value)} maxLength={500} />
      <button type="submit" disabled={!comment.trim() || addComment.isPending} aria-label="댓글 보내기"><Send size={15} /></button>
    </form>
    {error && <p className="inline-error">{error}</p>}
  </article>;
}

export function SocialFeed({ posts, loading, onChanged }: { posts: FeedPost[]; loading?: boolean; onChanged: () => void }) {
  if (loading) return <div className="skeleton-card" />;
  if (posts.length === 0) return <div className="empty-state"><span className="empty-mark"><Heart size={19} /></span><strong>아직 피드가 비어 있어요</strong><p>친구와 연결되면 서로의 소비 기록과 응원을 여기서 볼 수 있어요.</p></div>;
  return <div className="feed-list">{posts.map(post => <FeedCard key={post.id} post={post} onChanged={onChanged} />)}</div>;
}
