export function BrandMark({ size = 38 }: { size?: number }) {
  return (
    <img
      className="brand-mark"
      src="/mankkik-mark.png"
      width={Math.round(size * (634 / 532))}
      height={size}
      alt=""
      aria-hidden="true"
    />
  );
}

export function BrandLockup({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-lockup${compact ? " compact" : ""}`}>
      <BrandMark size={compact ? 34 : 42} />
      <div className="brand-wordmark">
        <span>만끽</span>
        {!compact && <small>좋은 소비를 함께</small>}
      </div>
    </div>
  );
}
