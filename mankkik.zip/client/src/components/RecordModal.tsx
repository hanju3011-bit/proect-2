import { useState, type ChangeEvent, type FormEvent } from "react";
import { ImagePlus, X } from "lucide-react";
import { trpc } from "@/lib/trpc";

type GoalOption = { id: number; title: string; startDate: Date; endDate: Date | null };
const categories = ["식비", "카페", "쇼핑", "교통", "문화·여가", "생활", "기타"];
const today = () => new Date().toLocaleDateString("sv-SE");
const toDataUrl = (file: File) => new Promise<string>((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("이미지를 읽지 못했어요."));
  reader.onerror = () => reject(new Error("이미지를 읽지 못했어요."));
  reader.readAsDataURL(file);
});

export function RecordModal({ open, onClose, goals, onCreated }: { open: boolean; onClose: () => void; goals: GoalOption[]; onCreated: () => void }) {
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("식비");
  const [memo, setMemo] = useState("");
  const [spentAt, setSpentAt] = useState(today());
  const [goalId, setGoalId] = useState("");
  const [imageData, setImageData] = useState("");
  const [imageName, setImageName] = useState("");
  const [error, setError] = useState("");
  const create = trpc.records.create.useMutation();
  const upload = trpc.media.upload.useMutation();

  if (!open) return null;
  const chooseImage = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setError("이미지는 5MB 이하로 업로드해 주세요."); return; }
    try { setImageData(await toDataUrl(file)); setImageName(file.name); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "이미지를 읽지 못했어요."); }
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError("");
    try {
      let imageUrl: string | null = null;
      if (imageData) imageUrl = (await upload.mutateAsync({ purpose: "record", dataUrl: imageData })).url;
      await create.mutateAsync({ amount: Number(amount), category, memo, spentAt: new Date(`${spentAt}T12:00:00`), goalId: goalId ? Number(goalId) : null, imageUrl });
      onCreated(); onClose();
      setAmount(""); setMemo(""); setGoalId(""); setImageData(""); setImageName("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "기록을 저장하지 못했어요."); }
  };
  const isBusy = create.isPending || upload.isPending;

  return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="record-modal-title">
      <div className="modal-heading"><div><span className="form-kicker">A MOMENT WORTH REMEMBERING</span><h2 id="record-modal-title">소비 기록 남기기</h2></div><button className="icon-button" onClick={onClose} aria-label="닫기"><X size={18} /></button></div>
      <form className="modal-form" onSubmit={submit}>
        <label className="field-label">소비 금액<input inputMode="numeric" type="number" min="1" max="1000000000" placeholder="0" value={amount} onChange={event => setAmount(event.target.value)} required autoFocus /></label>
        <div className="form-row"><label className="field-label">카테고리<select value={category} onChange={event => setCategory(event.target.value)}>{categories.map(item => <option key={item}>{item}</option>)}</select></label><label className="field-label">지출 날짜<input type="date" value={spentAt} onChange={event => setSpentAt(event.target.value)} required /></label></div>
        <label className="field-label">연결할 목표<select value={goalId} onChange={event => setGoalId(event.target.value)}><option value="">목표 없이 기록</option>{goals.map(goal => <option key={goal.id} value={goal.id}>{goal.title}</option>)}</select><small className="field-hint">목표를 선택하면 누적 소비액에 자동 반영돼요.</small></label>
        <label className="field-label">메모<textarea placeholder="무엇을 느꼈는지 짧게 적어보세요" value={memo} onChange={event => setMemo(event.target.value)} rows={3} maxLength={500} /></label>
        <label className={`upload-tile${imageData ? " has-preview" : ""}`}>
          {imageData ? <><img src={imageData} alt="첨부할 이미지 미리보기" /><span>{imageName}</span><button type="button" className="remove-image" onClick={event => { event.preventDefault(); setImageData(""); setImageName(""); }}>삭제</button></> : <><span className="upload-icon"><ImagePlus size={20} /></span><span><strong>사진 첨부</strong><small>영수증이나 기억하고 싶은 순간 · 최대 5MB</small></span><input type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseImage} /></>}
        </label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="modal-actions"><button className="secondary-button" type="button" onClick={onClose}>취소</button><button className="primary-button" type="submit" disabled={isBusy}>{isBusy ? "저장 중…" : "기록 저장"}</button></div>
      </form>
    </section>
  </div>;
}
