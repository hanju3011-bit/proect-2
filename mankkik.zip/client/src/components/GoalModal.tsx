import { useState, type FormEvent } from "react";
import { X } from "lucide-react";
import { trpc } from "@/lib/trpc";

const goalCategories = ["식비", "카페", "쇼핑", "교통", "문화·여가", "생활", "기타"];
const today = () => new Date().toLocaleDateString("sv-SE");

export function GoalModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("식비");
  const [targetAmount, setTargetAmount] = useState("");
  const [isUnlimited, setIsUnlimited] = useState(false);
  const [startDate, setStartDate] = useState(today());
  const [endDate, setEndDate] = useState("");
  const [error, setError] = useState("");
  const create = trpc.goals.create.useMutation();

  if (!open) return null;
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    try {
      await create.mutateAsync({ title, category, targetAmount: Number(targetAmount), isUnlimited, startDate: new Date(`${startDate}T00:00:00`), endDate: isUnlimited || !endDate ? null : new Date(`${endDate}T23:59:59`) });
      onCreated();
      onClose();
      setTitle(""); setTargetAmount(""); setEndDate("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "목표를 저장하지 못했어요."); }
  };

  return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="goal-modal-title">
      <div className="modal-heading"><div><span className="form-kicker">A LITTLE GOAL, A BETTER HABIT</span><h2 id="goal-modal-title">새 목표 만들기</h2></div><button className="icon-button" onClick={onClose} aria-label="닫기"><X size={18} /></button></div>
      <form className="modal-form" onSubmit={submit}>
        <label className="field-label">목표 이름<input placeholder="예: 평일 카페 지출 줄이기" value={title} onChange={event => setTitle(event.target.value)} required maxLength={80} /></label>
        <div className="form-row"><label className="field-label">카테고리<select value={category} onChange={event => setCategory(event.target.value)}>{goalCategories.map(item => <option key={item}>{item}</option>)}</select></label><label className="field-label">목표 금액<input inputMode="numeric" type="number" min="1" max="1000000000" placeholder="300000" value={targetAmount} onChange={event => setTargetAmount(event.target.value)} required /></label></div>
        <div className="form-row"><label className="field-label">시작일<input type="date" value={startDate} onChange={event => setStartDate(event.target.value)} required /></label>{!isUnlimited && <label className="field-label">종료일<input type="date" value={endDate} onChange={event => setEndDate(event.target.value)} required min={startDate} /></label>}</div>
        <label className="toggle-row"><span className="toggle-copy"><strong>기간 제한 없이 관리</strong><small>종료일 없이 계속 기록해요</small></span><input type="checkbox" checked={isUnlimited} onChange={event => { setIsUnlimited(event.target.checked); if (event.target.checked) setEndDate(""); }} /><span className="toggle-track" /></label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="modal-actions"><button className="secondary-button" type="button" onClick={onClose}>취소</button><button className="primary-button" type="submit" disabled={create.isPending}>{create.isPending ? "저장 중…" : "목표 만들기"}</button></div>
      </form>
    </section>
  </div>;
}
