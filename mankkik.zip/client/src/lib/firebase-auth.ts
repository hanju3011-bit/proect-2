import type { Auth, User } from "firebase/auth";

function firebaseConfig() {
  const config = window.__MANUS_CONFIG__?.firebase;
  if (!config?.apiKey || !config.authDomain || !config.projectId || !config.appId) {
    throw new Error("Google 로그인이 아직 설정되지 않았어요. Firebase 웹 앱 설정을 연결해 주세요.");
  }
  return config;
}

export function hasFirebaseConfig(): boolean {
  const config = window.__MANUS_CONFIG__?.firebase;
  return Boolean(config?.apiKey && config.authDomain && config.projectId && config.appId);
}

async function loadFirebaseAuth(): Promise<{ auth: Auth; sdk: typeof import("firebase/auth") }> {
  const config = firebaseConfig();
  const [appSdk, authSdk] = await Promise.all([import("firebase/app"), import("firebase/auth")]);
  const app = appSdk.getApps().some(existing => existing.name === "mankkik-auth")
    ? appSdk.getApp("mankkik-auth")
    : appSdk.initializeApp(config, "mankkik-auth");
  const auth = authSdk.getAuth(app);
  auth.languageCode = "ko";
  return { auth, sdk: authSdk };
}

export async function signInWithGoogle(): Promise<User | null> {
  const { auth, sdk } = await loadFirebaseAuth();
  const provider = new sdk.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });

  // Redirect authentication is more reliable on narrow/mobile browser contexts.
  if (window.matchMedia("(max-width: 700px)").matches) {
    await sdk.signInWithRedirect(auth, provider);
    return null;
  }

  const result = await sdk.signInWithPopup(auth, provider);
  return result.user;
}

export async function consumeGoogleRedirectResult(): Promise<User | null> {
  const { auth, sdk } = await loadFirebaseAuth();
  const result = await sdk.getRedirectResult(auth);
  return result?.user ?? null;
}

export async function signOutFirebase(): Promise<void> {
  if (!hasFirebaseConfig()) return;
  const { auth, sdk } = await loadFirebaseAuth();
  await sdk.signOut(auth);
}
