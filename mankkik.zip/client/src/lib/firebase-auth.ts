import type { Auth, User } from "firebase/auth";

type FirebaseAuthModule = typeof import("firebase/auth");
type LoadedFirebaseAuth = { auth: Auth; sdk: FirebaseAuthModule };

let authPromise: Promise<LoadedFirebaseAuth> | null = null;

function firebaseConfig() {
  const config = window.__MANUS_CONFIG__?.firebase;
  if (!config?.apiKey || !config.authDomain || !config.projectId || !config.appId) {
    throw new Error("Google 로그인이 아직 설정되지 않았어요. Firebase 웹 앱 설정을 연결해 주세요.");
  }
  return config;
}

export function hasFirebaseConfig(): boolean {
  const config = window.__MANUS_CONFIG__?.firebase;
  return Boolean(config?.apiKey && config.authDomain && config.projectId && config.appId);
}

function loadFirebaseAuth(): Promise<LoadedFirebaseAuth> {
  if (!authPromise) {
    authPromise = (async () => {
      const config = firebaseConfig();
      const [appSdk, authSdk] = await Promise.all([import("firebase/app"), import("firebase/auth")]);
      const app = appSdk.getApps().some(existing => existing.name === "mankkik-auth")
        ? appSdk.getApp("mankkik-auth")
        : appSdk.initializeApp(config, "mankkik-auth");
      const auth = authSdk.getAuth(app);
      auth.languageCode = "ko";
      return { auth, sdk: authSdk };
    })().catch(error => {
      authPromise = null;
      throw error;
    });
  }
  return authPromise;
}

/** Load Firebase before the user taps, so mobile popup creation stays close to the user gesture. */
export async function preloadFirebaseAuth(): Promise<void> {
  await loadFirebaseAuth();
}

export async function signInWithGoogle(): Promise<User> {
  const { auth, sdk } = await loadFirebaseAuth();
  const provider = new sdk.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });

  // The Manus-hosted app and Firebase authDomain are different sites. Popup auth avoids
  // mobile browsers' third-party-storage restrictions in signInWithRedirect flows.
  const result = await sdk.signInWithPopup(auth, provider);
  return result.user;
}

export async function consumeGoogleRedirectResult(): Promise<User | null> {
  const { auth, sdk } = await loadFirebaseAuth();
  const result = await sdk.getRedirectResult(auth);
  // Keep sessions from an older redirect-based build recoverable after an app update.
  return result?.user ?? auth.currentUser;
}

export async function signOutFirebase(): Promise<void> {
  if (!hasFirebaseConfig()) return;
  const { auth, sdk } = await loadFirebaseAuth();
  await sdk.signOut(auth);
}
