import { LoaderCircle } from "lucide-react";
import { Route, Switch } from "wouter";
import { trpc } from "@/lib/trpc";
import AuthPage from "./pages/AuthPage";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { TooltipProvider } from "@/components/ui/tooltip";

function AppContent() {
  const me = trpc.auth.me.useQuery(undefined, { retry: false, staleTime: 30_000 });
  const utils = trpc.useUtils();
  if (me.isPending) return <div className="app-loading"><span className="loading-brand">만끽</span><LoaderCircle className="spin" size={22} /><span>오늘의 공간을 준비하고 있어요</span></div>;
  if (!me.data) return <AuthPage onAuthenticated={() => { void utils.auth.me.invalidate(); }} />;
  return <Switch>
    <Route path="/" component={() => <Home user={me.data!} onLogout={() => { void utils.auth.me.invalidate(); }} />} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><AppContent /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
