import { useCallback, useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Check, Eye, EyeOff, Heart, ShieldCheck, Sparkles } from "lucide-react";
import type { User as FirebaseUser } from "firebase/auth";
import { BrandLockup } from "@/components/Brand";
import { trpc } from "@/lib/trpc";
import { consumeGoogleRedirectResult, hasFirebaseConfig, signInWithGoogle, signOutFirebase } from "@/lib/firebase-auth";

type AuthPageProps = { onAuthenticated: () => void };
type AuthMode = "google" | "legacy-login";

function authErrorMessage(error: unknown): string {
  const code = typeof error === "object" && error !== null && "code" in error ? String((error as { code?: unknown }).code ?? "") : "";
  if (code === "auth/unauthorized-domain") return "현재 사이트 주소가 Firebase 승인 도메인에 등록되지 않았어요.";
  if (code === "auth/operation-not-allowed") return "Firebase Console에서 Google 로그인을 사용 설정해 주세요.";
  if (code === "auth/popup-blocked") return "브라우저가 Google 로그인 창을 차단했어요. 팝업을 허용한 뒤 다시 시도해 주세요.";
  if (code === "auth/popup-closed-by-user") return "Google 로그인 창이 닫혔어요. 원하시면 다시 시도해 주세요.";
  if (code === "auth/network-request-failed") return "Firebase에 연결하지 못했어요. 네트워크와 Firebase 도메인 설정을 확인해 주세요.";
  if (error instanceof TypeError && /fetch/i.test(error.message)) return "로그인 서버에 연결할 수 없어요. 잠시 후 다시 시도해 주세요.";
  if (error instanceof Error && error.message) return error.message;
  return "로그인을 완료하지 못했어요. 다시 시도해 주세요.";
}

function GoogleMark() {
  return <svg aria-hidden="true" viewBox="0 0 48 48" width="20" height="20">
    <path fill="#4285F4" d="M43.6 24.5c0-1.4-.1-2.8-.4-4.1H24v7.8h11a9.4 9.4 0 0 1-4.1 6.2v5.1h6.6c3.9-3.6 6.1-8.8 6.1-15Z" />
    <path fill="#34A853" d="M24 44c5.5 0 10.1-1.8 13.5-4.8l-6.6-5.1c-1.8 1.2-4.1 2-6.9 2-5.3 0-9.8-3.6-11.4-8.5H5.8v5.3A20 20 0 0 0 24 44Z" />
    <path fill="#FBBC05" d="M12.6 27.6a12 12 0 0 1 0-7.2v-5.3H5.8a20 20 0 0 0 0 17.8l6.8-5.3Z" />
    <path fill="#EA4335" d="M24 11.9c3 0 5.7 1 7.8 3.1l5.9-5.9A19.6 19.6 0 0 0 24 4 20 20 0 0 0 5.8 15.1l6.8 5.3c1.6-4.9 6.1-8.5 11.4-8.5Z" />
  </svg>;
}

export default function AuthPage({ onAuthenticated }: AuthPageProps) {
  const [mode, setMode] = useState<AuthMode>("google");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isGooglePending, setIsGooglePending] = useState(false);
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const login = trpc.auth.login.useMutation();
  const firebaseLogin = trpc.auth.firebaseLogin.useMutation();
  const firebaseReady = hasFirebaseConfig();

  const completeGoogleLogin = useCallback(async (firebaseUser: FirebaseUser) => {
    setIsGooglePending(true);
    setError("");
    try {
      const idToken = await firebaseUser.getIdToken();
      await firebaseLogin.mutateAsync({ idToken });
      await utils.auth.me.invalidate();
      onAuthenticated();
    } catch (cause) {
      setError(authErrorMessage(cause));
      try { await signOutFirebase(); } catch { /* Server session is still revoked on explicit logout. */ }
    } finally {
      setIsGooglePending(false);
    }
  }, [firebaseLogin, onAuthenticated, utils.auth.me]);

  useEffect(() => {
    if (!firebaseReady) return;
    let active = true;
    void consumeGoogleRedirectResult()
      .then(user => { if (active && user) return completeGoogleLogin(user); })
      .catch(cause => { if (active) setError(authErrorMessage(cause)); });
    return () => { active = false; };
  }, [completeGoogleLogin, firebaseReady]);

  const submitLegacyLogin = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    try {
      await login.mutateAsync({ email, password });
      await utils.auth.me.invalidate();
      onAuthenticated();
    } catch (cause) {
      setError(authErrorMessage(cause));
    }
  };

  const startGoogleLogin = async () => {
    setError("");
    setIsGooglePending(true);
    try {
      const user = await signInWithGoogle();
      if (user) await completeGoogleLogin(user);
    } catch (cause) {
      setError(authErrorMessage(cause));
      setIsGooglePending(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="auth-story">
        <div className="auth-story-top"><BrandLockup /></div>
        <div className="auth-copy">
          <span className="eyebrow"><span className="eyebrow-dot" /> SPEND WELL, TOGETHER</span>
          <h1>아끼는 마음도<br /><em>함께하면</em> 오래가니까.</h1>
          <p>나의 소비를 돌아보고, 친구와 서로 응원하는<br className="desktop-break" /> 다정한 소비 습관을 시작해요.</p>
          <div className="story-points">
            <div><span className="point-icon"><Sparkles size={16} /></span><span>나만의 소비 목표</span><Check size={15} className="point-check" /></div>
            <div><span className="point-icon"><Heart size={16} /></span><span>친구와 함께하는 응원</span><Check size={15} className="point-check" /></div>
            <div><span className="point-icon"><ShieldCheck size={16} /></span><span>내 기록은 내가 관리</span><Check size={15} className="point-check" /></div>
          </div>
        </div>
        <div className="auth-story-foot"><span>소비를 기록하고, 마음을 나누고.</span><span>© MANKKIK</span></div>
      </section>

      <section className="auth-form-side">
        <div className="auth-form-wrap">
          <div className="mobile-brand"><BrandLockup compact /></div>
          <div className="auth-form-heading">
            <span className="form-kicker">YOUR MONEY, YOUR PACE</span>
            <h2>{mode === "google" ? "Google 계정으로 시작해요" : "다시 만나 반가워요"}</h2>
            <p>{mode === "google" ? "새 계정은 Google 로그인으로 간편하게 만들어요." : "기존 계정으로 소비 이야기를 이어가 볼까요?"}</p>
          </div>

          {mode === "google" ? (
            <div className="google-auth-stack">
              <button className="google-button" type="button" onClick={startGoogleLogin} disabled={!firebaseReady || isGooglePending}>
                {isGooglePending ? <span className="button-spinner" /> : <GoogleMark />}
                <span>{isGooglePending ? "Google에 연결하고 있어요…" : "Google로 계속하기"}</span>
              </button>
              {!firebaseReady && <p className="auth-config-note">Google 로그인을 시작하려면 Firebase 웹 앱 설정이 필요해요.</p>}
              {error && <div className="form-error" role="alert">{error}</div>}
            </div>
          ) : (
            <form className="auth-form" onSubmit={submitLegacyLogin}>
              <label className="field-label">이메일
                <input type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={event => setEmail(event.target.value)} required maxLength={320} />
              </label>
              <label className="field-label">비밀번호
                <div className="password-wrap">
                  <input type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="비밀번호를 입력해 주세요" value={password} onChange={event => setPassword(event.target.value)} required minLength={1} maxLength={128} />
                  <button type="button" className="password-toggle" onClick={() => setShowPassword(value => !value)} aria-label={showPassword ? "비밀번호 숨기기" : "비밀번호 보기"}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>
                </div>
              </label>
              {error && <div className="form-error" role="alert">{error}</div>}
              <button className="primary-button auth-submit" type="submit" disabled={login.isPending}>
                {login.isPending ? <span className="button-spinner" /> : <>기존 계정 로그인<ArrowRight size={17} /></>}
              </button>
            </form>
          )}

          <div className="auth-switch">
            {mode === "google" ? "이미 만끽 계정이 있나요?" : "새로 시작하시나요?"}
            <button onClick={() => { setError(""); setMode(mode === "google" ? "legacy-login" : "google"); }} type="button">{mode === "google" ? "기존 계정 로그인" : "Google로 시작하기"}</button>
          </div>
          <div className="auth-privacy"><ShieldCheck size={15} /><span>{mode === "google" ? "Google 계정으로 안전하게 시작해요." : "기존 계정 로그인은 보호된 앱 세션으로 유지돼요."}</span></div>
        </div>
        <div className="auth-side-bottom"><span>나의 속도로, 우리답게.</span><span>서비스 이용은 계정 생성 시 시작됩니다.</span></div>
      </section>
    </main>
  );
}
