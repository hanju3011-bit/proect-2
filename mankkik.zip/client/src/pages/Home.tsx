import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { ArrowDownRight, ArrowRight, ArrowUpRight, Bell, CalendarDays, Check, ChevronRight, CircleHelp, Compass, CreditCard, Heart, Home as HomeIcon, LogOut, Menu, Plus, Search, Settings2, ShieldCheck, Sparkles, Target, Users, Wallet, X } from "lucide-react";
import { toast } from "sonner";
import { BrandLockup } from "@/components/Brand";
import { GoalModal } from "@/components/GoalModal";
import { RecordModal } from "@/components/RecordModal";
import { SocialFeed } from "@/components/SocialFeed";
import { signOutFirebase } from "@/lib/firebase-auth";
import { trpc } from "@/lib/trpc";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";

type Output = inferRouterOutputs<AppRouter>;
type AppUser = NonNullable<Output["auth"]["me"]>;
type GoalItem = Output["goals"]["list"][number];
type RecordItem = Output["records"]["list"][number];
type FeedItem = Output["social"]["feed"][number];
type FriendRequest = Output["social"]["requests"][number];
type FriendItem = Output["social"]["friends"][number];
type View = "home" | "goals" | "records" | "friends" | "feed" | "profile";

const money = (amount: number) => `${new Intl.NumberFormat("ko-KR").format(amount)}원`;
const shortMoney = (amount: number) => amount >= 10000 ? `${(amount / 10000).toLocaleString("ko-KR", { maximumFractionDigits: 1 })}만` : money(amount);
const dateLabel = (date: Date | string) => new Intl.DateTimeFormat("ko-KR", { month: "long", day: "numeric" }).format(new Date(date));
const timeLabel = (date: Date | string) => new Intl.DateTimeFormat("ko-KR", { month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(date));
const thisMonth = (date: Date | string) => { const value = new Date(date); const now = new Date(); return value.getFullYear() === now.getFullYear() && value.getMonth() === now.getMonth(); };
const initials = (name: string) => name.trim().slice(0, 1) || "만";

function Avatar({ nickname, image, size = "md" }: { nickname: string; image?: string | null; size?: "sm" | "md" | "lg" }) {
  return <span className={`avatar avatar-${size}`}>{image ? <img src={image} alt={`${nickname} 프로필`} /> : initials(nickname)}</span>;
}

const navItems: { id: View; label: string; icon: typeof HomeIcon }[] = [
  { id: "home", label: "홈", icon: HomeIcon },
  { id: "goals", label: "목표", icon: Target },
  { id: "records", label: "소비 기록", icon: Wallet },
  { id: "friends", label: "친구", icon: Users },
  { id: "feed", label: "소셜 피드", icon: Heart },
];

export default function Home({ user, onLogout }: { user: AppUser; onLogout: () => void }) {
  const [view, setView] = useState<View>("home");
  const [goalModalOpen, setGoalModalOpen] = useState(false);
  const [recordModalOpen, setRecordModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [olderRecords, setOlderRecords] = useState<RecordItem[]>([]);
  const [hasMoreRecords, setHasMoreRecords] = useState(true);
  const [loadingMoreRecords, setLoadingMoreRecords] = useState(false);
  const utils = trpc.useUtils();
  const goalsQuery = trpc.goals.list.useQuery();
  const recordsQuery = trpc.records.list.useQuery({ limit: 50, offset: 0 });
  const monthRange = useMemo(() => { const now = new Date(); return { startAt: new Date(now.getFullYear(), now.getMonth(), 1), endBefore: new Date(now.getFullYear(), now.getMonth() + 1, 1) }; }, []);
  const monthSummaryQuery = trpc.records.summary.useQuery(monthRange);
  const feedQuery = trpc.social.feed.useQuery({ limit: 30 }, { refetchInterval: 10_000 });
  const friendsQuery = trpc.social.friends.useQuery();
  const requestsQuery = trpc.social.requests.useQuery();
  const logout = trpc.auth.logout.useMutation();
  const goals = goalsQuery.data ?? [];
  const records = [...(recordsQuery.data ?? []), ...olderRecords];
  const feed = feedQuery.data ?? [];
  const friends = friendsQuery.data ?? [];
  const requests = requestsQuery.data ?? [];
  const monthSpend = monthSummaryQuery.data?.total ?? 0;
  const monthRecordCount = monthSummaryQuery.data?.count ?? 0;
  useEffect(() => { if (recordsQuery.data) setHasMoreRecords(recordsQuery.data.length === 50); }, [recordsQuery.data]);

  const refreshData = async () => {
    setOlderRecords([]);
    setHasMoreRecords(true);
    await Promise.all([utils.goals.list.invalidate(), utils.records.list.invalidate(), utils.records.summary.invalidate(), utils.social.feed.invalidate()]);
  };
  const loadMoreRecords = async () => {
    setLoadingMoreRecords(true);
    try {
      const page = await utils.records.list.fetch({ limit: 50, offset: records.length });
      setOlderRecords(current => [...current, ...page]);
      setHasMoreRecords(page.length === 50);
    } catch { toast.error("이전 기록을 불러오지 못했어요."); }
    finally { setLoadingMoreRecords(false); }
  };
  const saveLogout = async () => {
    try { await logout.mutateAsync(); } catch { toast.error("로그아웃하지 못했어요. 다시 시도해 주세요."); return; }
    try { await signOutFirebase(); } catch { /* The application session is already cleared. */ }
    await utils.auth.me.invalidate(); onLogout();
  };
  const setCurrentView = (next: View) => { setView(next); setMobileMenuOpen(false); };

  return <div className="app-shell">
    <aside className={`sidebar${mobileMenuOpen ? " sidebar-open" : ""}`}>
      <div className="sidebar-brand"><BrandLockup /></div>
      <div className="sidebar-caption">YOUR SPACE</div>
      <nav className="side-nav" aria-label="주 메뉴">
        {navItems.map(item => {
          const Icon = item.icon;
          return <button key={item.id} className={`nav-item${view === item.id ? " active" : ""}`} onClick={() => setCurrentView(item.id)}><Icon size={18} strokeWidth={1.8} /><span>{item.label}</span>{item.id === "friends" && requests.length > 0 && <i className="nav-badge">{requests.length}</i>}</button>;
        })}
      </nav>
      <div className="sidebar-grow" />
      <div className="sidebar-nudge"><span className="nudge-spark"><Sparkles size={15} /></span><strong>작은 기록이<br />큰 변화를 만들어요.</strong><span>오늘도 나다운 소비를 응원해요.</span></div>
      <button className={`profile-nav${view === "profile" ? " active" : ""}`} onClick={() => setCurrentView("profile")}><Avatar nickname={user.nickname} image={user.profileImg} /><span className="profile-nav-copy"><strong>{user.nickname}</strong><small>@{user.publicId}</small></span><Settings2 size={17} /></button>
      <button className="logout-link" onClick={saveLogout} disabled={logout.isPending}><LogOut size={16} />로그아웃</button>
      <div className="sidebar-foot"><span>만끽 · 함께 만드는 좋은 소비</span><button aria-label="도움말"><CircleHelp size={15} /></button></div>
    </aside>

    {mobileMenuOpen && <button className="mobile-menu-scrim" aria-label="메뉴 닫기" onClick={() => setMobileMenuOpen(false)} />}
    <div className="workspace">
      <header className="topbar">
        <div className="topbar-left"><button className="mobile-menu-button" onClick={() => setMobileMenuOpen(value => !value)} aria-label="메뉴 열기"><Menu size={20} /></button><span className="breadcrumb">내 공간 <ChevronRight size={14} /> <strong>{navItems.find(item => item.id === view)?.label ?? "프로필"}</strong></span></div>
        <div className="topbar-actions"><span className="today-chip"><CalendarDays size={14} />{new Intl.DateTimeFormat("ko-KR", { month: "long", day: "numeric", weekday: "short" }).format(new Date())}</span><button className="icon-button notification-button" aria-label="알림"><Bell size={18} /><i /></button><button className="topbar-profile" onClick={() => setCurrentView("profile")}><Avatar nickname={user.nickname} image={user.profileImg} size="sm" /></button></div>
      </header>
      <main className="page-content">
        {view === "home" && <Overview user={user} goals={goals} records={records} feed={feed} friendsCount={friends.length} monthSpend={monthSpend} monthRecordCount={monthRecordCount} onOpenGoals={() => setCurrentView("goals")} onOpenRecords={() => setCurrentView("records")} onOpenFeed={() => setCurrentView("feed")} onOpenFriends={() => setCurrentView("friends")} onCreateGoal={() => setGoalModalOpen(true)} onCreateRecord={() => setRecordModalOpen(true)} onRefresh={() => utils.social.feed.invalidate()} loading={goalsQuery.isPending || recordsQuery.isPending || monthSummaryQuery.isPending} />}
        {view === "goals" && <GoalsPage goals={goals} loading={goalsQuery.isPending} onCreate={() => setGoalModalOpen(true)} />}
        {view === "records" && <RecordsPage records={records} loading={recordsQuery.isPending} hasMore={hasMoreRecords} loadingMore={loadingMoreRecords} onLoadMore={loadMoreRecords} onCreate={() => setRecordModalOpen(true)} />}
        {view === "friends" && <FriendsPage requests={requests} friends={friends} onChanged={async () => { await Promise.all([utils.social.requests.invalidate(), utils.social.friends.invalidate(), utils.social.search.invalidate()]); }} />}
        {view === "feed" && <FeedPage posts={feed} loading={feedQuery.isPending} onChanged={() => utils.social.feed.invalidate()} />}
        {view === "profile" && <ProfilePage user={user} onSaved={() => utils.auth.me.invalidate()} />}
      </main>
      <div className="mobile-bottom-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={view === item.id ? "active" : ""} onClick={() => setCurrentView(item.id)}><Icon size={19} /><span>{item.label === "소비 기록" ? "기록" : item.label === "소셜 피드" ? "피드" : item.label}</span></button>; })}</div>
    </div>
    <GoalModal open={goalModalOpen} onClose={() => setGoalModalOpen(false)} onCreated={refreshData} />
    <RecordModal open={recordModalOpen} onClose={() => setRecordModalOpen(false)} goals={goals.map(goal => ({ id: goal.id, title: goal.title, startDate: goal.startDate, endDate: goal.endDate }))} onCreated={refreshData} />
  </div>;
}

function PageHeading({ kicker, title, description, action }: { kicker: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-heading"><div><span className="form-kicker">{kicker}</span><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}

function Overview({ user, goals, records, feed, friendsCount, monthSpend, monthRecordCount, onOpenGoals, onOpenRecords, onOpenFeed, onOpenFriends, onCreateGoal, onCreateRecord, onRefresh, loading }: {
  user: AppUser; goals: GoalItem[]; records: RecordItem[]; feed: FeedItem[]; friendsCount: number; monthSpend: number; monthRecordCount: number;
  onOpenGoals: () => void; onOpenRecords: () => void; onOpenFeed: () => void; onOpenFriends: () => void; onCreateGoal: () => void; onCreateRecord: () => void; onRefresh: () => void; loading: boolean;
}) {
  const currentGoals = goals.filter(goal => goal.endDate === null || new Date(goal.endDate) >= new Date()).slice(0, 3);
  const recentRecords = records.slice(0, 4);
  return <>
    <div className="welcome-line"><span className="welcome-greeting">좋은 하루예요, {user.nickname}님 <span>✳</span></span><span className="welcome-note">오늘도 나에게 맞는 속도로.</span></div>
    <section className="hero-panel">
      <div className="hero-glow" />
      <div className="hero-copy"><span className="hero-eyebrow"><span /> THIS MONTH, WITH INTENTION</span><h1>소비를 살펴보면<br />마음이 <em>가벼워져요.</em></h1><p>기록은 나를 탓하는 일이 아니라,<br />더 나은 선택을 응원하는 일이니까요.</p><button className="hero-button" onClick={onCreateRecord}><Plus size={17} />오늘의 소비 기록하기</button></div>
      <div className="hero-stats"><span className="hero-stats-label">이번 달 기록한 소비</span><strong>{loading ? "—" : money(monthSpend)}</strong><span className="hero-stat-sub"><span className="green-dot" />{monthRecordCount}개의 기록으로 돌아보는 중</span><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-corner-mark">m.</div></div>
      <div className="hero-index">01 <span>/</span> 04</div>
    </section>
    <div className="quick-stats">
      <StatCard icon={<Target size={18} />} label="진행 중인 목표" value={`${goals.filter(goal => goal.endDate === null || new Date(goal.endDate) >= new Date()).length}`} unit="개" tint="lime" foot="나만의 페이스로 진행 중" />
      <StatCard icon={<Wallet size={18} />} label="이번 달 기록" value={`${monthRecordCount}`} unit="건" tint="violet" foot="소비를 돌아보는 작은 습관" />
      <StatCard icon={<Users size={18} />} label="함께하는 친구" value={`${friendsCount}`} unit="명" tint="amber" foot="응원은 서로에게 힘이 돼요" />
    </div>
    <div className="content-grid">
      <section className="content-column">
        <div className="section-title-row"><div><span className="section-kicker">YOUR INTENTIONS</span><h2>나의 목표</h2></div><button className="text-link" onClick={onOpenGoals}>모두 보기 <ArrowRight size={15} /></button></div>
        {currentGoals.length === 0 ? <div className="empty-inline"><span className="empty-mark"><Target size={18} /></span><div><strong>첫 번째 목표를 만들어 볼까요?</strong><p>작은 기준 하나가 소비의 방향을 잡아줘요.</p></div><button className="mini-add" onClick={onCreateGoal}><Plus size={16} /></button></div> : <div className="goal-mini-list">{currentGoals.map(goal => <GoalCard key={goal.id} goal={goal} />)}</div>}
        <div className="section-title-row section-gap"><div><span className="section-kicker">RECENT MOMENTS</span><h2>최근 소비 기록</h2></div><button className="text-link" onClick={onOpenRecords}>기록 살펴보기 <ArrowRight size={15} /></button></div>
        {recentRecords.length === 0 ? <div className="empty-inline"><span className="empty-mark"><Wallet size={18} /></span><div><strong>기록이 쌓이면 흐름이 보여요</strong><p>오늘의 소비를 가볍게 남겨보세요.</p></div><button className="mini-add" onClick={onCreateRecord}><Plus size={16} /></button></div> : <div className="recent-list">{recentRecords.map(record => <RecordRow key={record.id} record={record} />)}</div>}
      </section>
      <aside className="right-column">
        <div className="section-title-row"><div><span className="section-kicker">A LITTLE ENCOURAGEMENT</span><h2>친구들의 소식</h2></div><button className="round-arrow" onClick={onOpenFeed} aria-label="피드 전체 보기"><ArrowUpRight size={17} /></button></div>
        <SocialFeed posts={feed.slice(0, 2)} loading={false} onChanged={onRefresh} />
        <div className="friend-invite-card"><div className="invite-icon"><Heart size={17} /></div><div><strong>함께하면 더 즐거워요</strong><p>친구와 기록을 나누고 서로 응원해요.</p></div><button onClick={onOpenFriends}><ArrowRight size={16} /></button></div>
      </aside>
    </div>
  </>;
}

function StatCard({ icon, label, value, unit, tint, foot }: { icon: ReactNode; label: string; value: string; unit: string; tint: string; foot: string }) {
  return <div className="stat-card"><span className={`stat-icon ${tint}`}>{icon}</span><span className="stat-label">{label}</span><span className="stat-value">{value}<small>{unit}</small></span><span className="stat-foot">{foot}</span></div>;
}

function GoalCard({ goal }: { goal: GoalItem }) {
  const percent = Math.min(100, goal.progressPercent);
  return <article className="goal-card"><div className="goal-card-head"><span className="goal-category-mark"><Target size={16} /></span><span className="goal-category">{goal.category}</span><span className={`period-pill${goal.isUnlimited ? " unlimited" : ""}`}>{goal.isUnlimited ? "무제한" : `${dateLabel(goal.endDate!)}까지`}</span></div><h3>{goal.title}</h3><div className="goal-numbers"><strong>{money(goal.currentAmount)}</strong><span>목표 {money(goal.targetAmount)}</span></div><div className="progress-track"><span style={{ width: `${percent}%` }} /></div><div className="progress-meta"><span>{percent}% 달성</span><span>{goal.remainingAmount === 0 ? "목표 금액 도달" : `${money(goal.remainingAmount)} 남음`}</span></div></article>;
}

function RecordRow({ record }: { record: RecordItem }) {
  return <article className="record-row"><span className="record-category-icon"><CreditCard size={16} /></span><div className="record-row-main"><strong>{record.memo?.trim() || record.category}</strong><span>{dateLabel(record.spentAt)}{record.goalTitle ? ` · ${record.goalTitle}` : ""}</span></div>{record.imageUrl && <span className="record-thumb"><img src={record.imageUrl} alt="첨부 사진" /></span>}<span className="record-amount">−{money(record.amount)}</span></article>;
}

function GoalsPage({ goals, loading, onCreate }: { goals: GoalItem[]; loading: boolean; onCreate: () => void }) {
  return <><PageHeading kicker="GOALS, ON YOUR TERMS" title="나의 목표" description="정해진 기간도, 끝없는 습관도. 내게 맞는 방식으로 관리해요." action={<button className="primary-button" onClick={onCreate}><Plus size={17} />새 목표</button>} />
    {loading ? <div className="skeleton-card" /> : goals.length ? <div className="goal-page-grid">{goals.map(goal => <GoalCard key={goal.id} goal={goal} />)}</div> : <div className="empty-state page-empty"><span className="empty-mark"><Target size={20} /></span><strong>아직 목표가 없어요</strong><p>작은 계획 하나로 소비의 방향을 만들어 보세요.</p><button className="primary-button" onClick={onCreate}><Plus size={16} />첫 목표 만들기</button></div>}
  </>;
}

function RecordsPage({ records, loading, hasMore, loadingMore, onLoadMore, onCreate }: { records: RecordItem[]; loading: boolean; hasMore: boolean; loadingMore: boolean; onLoadMore: () => void; onCreate: () => void }) {
  return <><PageHeading kicker="YOUR SPENDING JOURNAL" title="소비 기록" description="잘 쓴 돈도, 돌아볼 소비도. 있는 그대로 기록해요." action={<button className="primary-button" onClick={onCreate}><Plus size={17} />기록 남기기</button>} />
    {loading ? <div className="skeleton-card" /> : records.length ? <><div className="records-panel"><div className="records-panel-head"><span>내 기록</span><span>{records.length}건 불러옴</span></div>{records.map(record => <RecordRow key={record.id} record={record} />)}</div>{hasMore && <button className="load-more-button" onClick={onLoadMore} disabled={loadingMore}>{loadingMore ? "불러오는 중…" : "이전 기록 더 보기"}<ArrowDownRight size={15} /></button>}</> : <div className="empty-state page-empty"><span className="empty-mark"><Wallet size={20} /></span><strong>첫 기록을 남겨볼까요?</strong><p>날짜, 금액, 마음을 담은 한 줄이면 충분해요.</p><button className="primary-button" onClick={onCreate}><Plus size={16} />소비 기록 남기기</button></div>}
  </>;
}

function FeedPage({ posts, loading, onChanged }: { posts: FeedItem[]; loading: boolean; onChanged: () => void }) {
  return <><PageHeading kicker="BETTER, TOGETHER" title="소셜 피드" description="친구의 작은 실천에 다정한 응원을 보내보세요." /><div className="feed-page-layout"><div className="feed-page-main"><SocialFeed posts={posts} loading={loading} onChanged={onChanged} /></div><aside className="feed-note"><span className="note-mark"><Heart size={18} /></span><span className="section-kicker">A KIND REMINDER</span><strong>비교 대신,<br />응원을 건네요.</strong><p>좋은 소비 습관은 저마다 다른 모습이에요. 친구의 선택을 함께 축하해 주세요.</p><div className="note-line" /></aside></div></>;
}

function FriendsPage({ requests, friends, onChanged }: { requests: FriendRequest[]; friends: FriendItem[]; onChanged: () => void }) {
  const [query, setQuery] = useState("");
  const [sent, setSent] = useState<number[]>([]);
  const search = trpc.social.search.useQuery({ query }, { enabled: query.trim().length >= 2 });
  const send = trpc.social.sendRequest.useMutation();
  const respond = trpc.social.respond.useMutation();
  const submitSearch = (event: FormEvent) => event.preventDefault();
  const sendTo = async (id: number) => { try { await send.mutateAsync({ receiverId: id }); setSent(values => [...values, id]); toast.success("친구 신청을 보냈어요."); await onChanged(); } catch (cause) { toast.error(cause instanceof Error ? cause.message : "신청을 보내지 못했어요."); } };
  const answer = async (requesterId: number, accept: boolean) => { try { await respond.mutateAsync({ requesterId, accept }); toast.success(accept ? "친구가 되었어요." : "신청을 거절했어요."); await onChanged(); } catch (cause) { toast.error(cause instanceof Error ? cause.message : "신청을 처리하지 못했어요."); } };
  return <><PageHeading kicker="YOUR PEOPLE, YOUR PACE" title="친구" description="소비를 공유하고 서로의 작은 변화를 응원해요." />
    <div className="friends-layout"><section className="friends-main">
      <div className="panel-card search-panel"><div className="section-title-row"><div><span className="section-kicker">FIND YOUR PEOPLE</span><h2>친구 찾기</h2></div><span className="quiet-count">닉네임 또는 ID</span></div><form className="friend-search" onSubmit={submitSearch}><Search size={18} /><input placeholder="닉네임이나 만끽 ID를 검색해요" value={query} onChange={event => setQuery(event.target.value)} /><button className="primary-button" type="submit" disabled={query.trim().length < 2}>검색</button></form>
        {query.trim().length >= 2 && <div className="search-results">{search.isPending ? <span className="muted-line">찾는 중…</span> : search.data?.length ? search.data.map(person => <div className="person-row" key={person.id}><Avatar nickname={person.nickname} image={person.profileImg} /><span className="person-copy"><strong>{person.nickname}</strong><small>@{person.publicId}</small></span><button className={`small-outline${sent.includes(person.id) ? " is-sent" : ""}`} disabled={send.isPending || sent.includes(person.id)} onClick={() => sendTo(person.id)}>{sent.includes(person.id) ? <><Check size={14} />신청 완료</> : <><Plus size={14} />친구 신청</>}</button></div>) : <div className="empty-search">검색 결과가 없어요.</div>}</div>}
      </div>
      <div className="panel-card requests-panel"><div className="section-title-row"><div><span className="section-kicker">WAITING FOR YOU</span><h2>받은 친구 신청</h2></div><span className="count-pill">{requests.length}</span></div>{requests.length ? requests.map(request => <div className="person-row" key={request.id}><Avatar nickname={request.nickname ?? "만끽 사용자"} image={request.profileImg} /><span className="person-copy"><strong>{request.nickname ?? "만끽 사용자"}</strong><small>@{request.publicId ?? request.requesterId} · 신청을 보냈어요</small></span><div className="request-actions"><button className="accept-button" onClick={() => answer(request.requesterId, true)} aria-label="친구 신청 수락"><Check size={16} /></button><button className="decline-button" onClick={() => answer(request.requesterId, false)} aria-label="친구 신청 거절"><X size={16} /></button></div></div>) : <p className="muted-line request-empty">새로운 신청이 오면 여기에 보여요.</p>}</div>
    </section><aside className="panel-card friends-list-panel"><div className="section-title-row"><div><span className="section-kicker">YOUR CIRCLE</span><h2>함께하는 친구</h2></div><span className="count-pill">{friends.length}</span></div>{friends.length ? friends.map(friend => <div className="person-row" key={friend.id}><Avatar nickname={friend.nickname} image={friend.profileImg} /><span className="person-copy"><strong>{friend.nickname}</strong><small>@{friend.publicId}</small></span><span className="friend-presence"><i /> 함께해요</span></div>) : <div className="friends-empty"><span className="empty-mark"><Users size={18} /></span><strong>아직 친구가 없어요</strong><p>위에서 닉네임이나 ID로 찾아보세요.</p></div>}</aside></div>
  </>;
}

function ProfilePage({ user, onSaved }: { user: AppUser; onSaved: () => void }) {
  const [nickname, setNickname] = useState(user.nickname);
  const [imageData, setImageData] = useState("");
  const [preview, setPreview] = useState<string | null>(user.profileImg);
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const upload = trpc.media.upload.useMutation();
  const update = trpc.profile.update.useMutation();
  const onSelectImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setError("이미지는 5MB 이하로 업로드해 주세요."); return; }
    const reader = new FileReader(); reader.onload = () => { const value = typeof reader.result === "string" ? reader.result : ""; setImageData(value); setPreview(value); setError(""); }; reader.readAsDataURL(file);
  };
  const save = async (event: FormEvent) => {
    event.preventDefault(); setError("");
    try {
      let profileImg = user.profileImg;
      if (imageData) profileImg = (await upload.mutateAsync({ purpose: "profile", dataUrl: imageData })).url;
      await update.mutateAsync({ nickname, profileImg });
      await utils.auth.me.invalidate();
      setImageData(""); onSaved(); toast.success("프로필을 저장했어요.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "프로필을 저장하지 못했어요."); }
  };
  return <><PageHeading kicker="YOUR PROFILE, YOUR WAY" title="프로필 설정" description="친구들에게 보여질 이름과 프로필 사진을 관리해요." />
    <div className="profile-layout"><form className="panel-card profile-form" onSubmit={save}><span className="section-kicker">PERSONAL DETAILS</span><h2>내 프로필</h2><div className="profile-photo-row"><Avatar nickname={nickname || user.nickname} image={preview} size="lg" /><label className="small-outline photo-picker">사진 변경<input type="file" accept="image/jpeg,image/png,image/webp" onChange={onSelectImage} /></label><span className="field-hint">JPG, PNG, WebP · 최대 5MB</span></div><label className="field-label">닉네임<input value={nickname} onChange={event => setNickname(event.target.value)} required minLength={2} maxLength={24} /></label><label className="field-label">이메일<input value={user.email ?? ""} readOnly disabled /></label><label className="field-label">만끽 ID<input value={`@${user.publicId}`} readOnly disabled /></label>{error && <p className="form-error" role="alert">{error}</p>}<button type="submit" className="primary-button" disabled={update.isPending || upload.isPending}>{update.isPending || upload.isPending ? "저장 중…" : "변경 사항 저장"}</button></form><aside className="profile-side-note"><ShieldCheck size={20} /><strong>나의 기록은<br />안전하게 보호돼요.</strong><p>비밀번호는 해시 형태로 저장되며, 소비 기록과 사진은 내 계정에서 관리해요.</p><span>계정 생성일 이후, 필요할 때 언제든 프로필을 바꿀 수 있어요.</span></aside></div>
  </>;
}
